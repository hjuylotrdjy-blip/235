# ☁️ النشر على Google (AI Studio / Cloud Run)

## أولاً: الحقيقة اللي خاصك تعرفها

Google AI Studio فيه زر **Publish / Deploy** كينشر التطبيق على **Cloud Run** وكيعطيك رابط فيه HTTPS مجاني:

- `https://ytultra-xxxxx-ew.a.run.app` (Cloud Run)
- أو دومين مخصص مجاني: `https://ytultra.ai.studio` (اختيار الاسم وقت النشر، أول واحد كياخذو)
- الحسابات الجديدة: **تطبيقين مجاناً بلا بطاقة بنكية** (Google Cloud Starter Tier)

⚠️ **لكن**: AI Studio Build كيبني تطبيقات ديالو (React/TS + server code ديال Google). **ما كيقبلش ترفع ليه كودبايز Python جاهز** بحال ours (Flask + yt-dlp + ffmpeg + SQLite). إلا حاولتي تلصق الكود تما، الـagent غادي يعاود يكتبو من الصفر و يخسر yt-dlp/ffmpeg.

**الحل الصحيح:** نفس البنية التحتية (Cloud Run) ولكن النشر المباشر بالكود ديالك عبر `gcloud`. النتيجة: نفس الدومين المجاني + كودك محفوظ 100%.

| الطريق | يخدم مع كودنا؟ | الدومين |
|---|---|---|
| AI Studio → Publish | ❌ كيعاود يبني التطبيق | `*.run.app` أو `*.ai.studio` |
| **Cloud Run مباشرة (gcloud)** | ✅ **نعم، جاهز** | `*.run.app` + دومين مخصص |
| Cloud Run + ربط الدومين | ✅ | `ytultra.com` |

---

## ✅ الطريقة 1 — Cloud Run بأمر واحد (موصى بها)

### 1) تثبيت gcloud (فجهازك أو من Cloud Shell)
```bash
# Cloud Shell (بلا تثبيت): https://console.cloud.google.com/ → أيقونة Terminal
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
gcloud init
gcloud auth login
```

### 2) إنشاء مشروع + تفعيل الفاتورة
```bash
gcloud projects create ytultra-prod --name="ytultra"
gcloud config set project ytultra-prod
```
> الفاتورة ضرورية للـCloud Run العادي (ولكن فيه **free tier**: 2 مليون request/شهر + 180K vCPU-second مجاناً).

### 3) النشر
```bash
cd ytultra
chmod +x deploy/cloudrun.sh
./deploy/cloudrun.sh ytultra europe-west1
```

السكريبت كيدير:
1. تفعيل APIs (Run, Build, Artifact Registry)
2. يطلب كلمة سر الـadmin + يولّد `SECRET_KEY`
3. `gcloud run deploy --source .` (كيبني الـDockerfile)
4. كيعطيك الرابط و كيحدّد `PUBLIC_BASE_URL` أوتوماتيك

### 4) تحقق
```bash
curl https://ytultra-xxx-ew.a.run.app/healthz
# {"ffmpeg":true,"ok":true,"pages":45}
```

### 5) أوامر مفيدة
```bash
gcloud run services list
gcloud run logs tail ytultra --region europe-west1
gcloud run services update ytultra --region europe-west1 --set-env-vars GEMINI_API_KEY=xxx
gcloud run services delete ytultra --region europe-west1
```

---

## 🔧 إعدادات Cloud Run الخاصّة بهاد التطبيق (مهمة)

| الإعداد | القيمة | علاش |
|---|---|---|
| `--max-instances 1` | **إلزامي** | التحميلات فالميموري (dict). أكثر من instance = job يضيع |
| `--timeout 3600` | 60 دقيقة | فيديوهات 4K طويلة |
| `--memory 2Gi` / `--cpu 2` | | ffmpeg كيحتاج RAM فـ الدمج |
| `--session-affinity` | مفعّل | باش الـadmin و الـpolling يبقاو على نفس الـinstance |
| `--min-instances 0` | يوفّر فلوس | ولكن أول طلب كياخد ~2 ثانية (cold start) |
| `--concurrency 20` | | threads كافية |
| `YTULTRA_DB=/tmp/data.db` | | Cloud Run read-only ما عدا `/tmp` |
| `JOBS_DIR=/tmp/ytultra-jobs` | | نفس السبب |

### ⚠️ حدود Cloud Run اللي خاصك تعرفها

1. **`/tmp` مؤقت و فالميموري** → `data.db` كيتمسح فكل cold start:
   - صفحات pSEO المخصصة، الإحصائيات، و**كلمة سر الـadmin** كيرجعو للافتراضي.
   - الحل الدائم: **Firestore** أو **Cloud SQL** أو **GCS volume mount**. (عندي ليك بديل جاهز تحت 👇)
   - الحل السريع: خلي `ADMIN_PASSWORD` فـ env var (كيترجع فكل restart) + `SECRET_KEY` ثابت.
2. **`--min-instances 0`** → ملي كيطفي، الملفات المؤقتة كتمشي (الملف اللي كان كيتحمّل كيتلغى).
3. **IP ديال Google Cloud** → يوتيوب كيحظرو بزاف: `Sign in to confirm you're not a bot`.
   → خاصك `cookiefile` (شوف تحت) أو proxy.
4. **الحجم**: `/tmp` كيتحسب من RAM → ما تفوتش `--memory 2Gi`، فيديوهات 4K كبيرة تقدر تفشل.

### 🔐 الحل الدائم للـDB (اختياري، 10 دقايق)
بدّل SQLite بـFirestore، أوMount bucket:
```bash
gcloud storage buckets create gs://ytultra-data --location=europe-west1
gcloud run services update ytultra --region europe-west1 \
  --add-volume name=data,type=cloud-storage,bucket=ytultra-data \
  --add-volume-mount volume=data,mount-path=/data \
  --update-env-vars YTULTRA_DB=/data/data.db,JOBS_DIR=/tmp/ytultra-jobs
```
> ملاحظة: GCS mount كيتصرف بحال NFS — بطيء شوية على SQLite. الأحسن Firestore إلا بغيت جدية.

---

## 🍪 حلّ مشكل "Sign in to confirm you're not a bot"

1. فـ Chrome، دير login لـYouTube، ثم استعمل extension **Get cookies.txt LOCALLY**.
2. صدّر `youtube.com_cookies.txt`.
3. حوّلو لـSecret على Cloud Run:
```bash
gcloud secrets create yt-cookies --data-file=youtube.com_cookies.txt
gcloud run services update ytultra --region europe-west1 \
  --set-secrets /app/cookies.txt=yt-cookies:latest
```
4. فـ `downloader.py` فـ `ydl_base_opts()` زيد:
```python
"cookiefile": "/app/cookies.txt",
```
5. أعد النشر: `./deploy/cloudrun.sh`

> الكوكيز كتنتهي صلاحيتها (أسابيع). عاود جددها ملي يبدا يفشل التحميل.

---

## 🌐 الطريقة 2 — ربط دومين ديالك (اختياري)

فيه جوج طرق:
```bash
# A) دومين مخصص على Cloud Run (يتطلب التحقق من الملكية)
gcloud run domain-mappings create --service ytultra --domain ytultra.com --region europe-west1
# كيعطيك سجلات DNS زيدهم عند الـregistrar
```
```bash
# B) عبر Load Balancer + Google-managed SSL (أكثر مرونة)
# Console → Network services → Load balancing → Backend = Cloud Run
```

بعد ربط الدومين، حدّث:
```bash
gcloud run services update ytultra --region europe-west1 \
  --update-env-vars PUBLIC_BASE_URL=https://ytultra.com
```
حتى `/sitemap.xml` و `<link rel="canonical">` كيتحدّثو أوتوماتيك.

---

## 🤖 الطريقة 3 — استعمال AI Studio بشكل صحيح (Gemini API)

بدل ما تعاود تبني التطبيق تما، استعمل **Gemini** جوّا التطبيق ديالك:

1. خد كلید من [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. زيدو:
```bash
gcloud run services update ytultra --region europe-west1 \
  --update-env-vars GEMINI_API_KEY=AIza...
```
3. دخل لـ`/admin/ai` → كتب موضوع → **Générer la page**
   → Gemini كيكتب ليك: `title`, `meta description`, `H1`, `intro`, `body`, `FAQ`, `slug`
   → كتخلق **صفحة pSEO جديدة** فـ حالة brouillon، كتراجعها و كتنشرها بضغطة.

هاد الشي كيخليك تولّد **مئات الصفحات SEO** بسرعة، وكل واحدة كتراجعها قبل النشر.
(الموديل الافتراضي: `gemini-2.5-flash` — بدلو بـ`GEMINI_MODEL`.)

---

## 📊 التكلفة المتوقعة

| المورد | Free tier شهري | بعدو |
|---|---|---|
| Cloud Run requests | 2 مليون | ~0.40$/مليون |
| vCPU | 180,000 ثانية | ~0.000024$/ثانية |
| RAM | 360,000 GiB-ثانية | ~0.0000025$/GiB-ث |
| Cloud Build | 120 دقيقة/يوم | — |
| Egress | 1 GB | ~0.12$/GB |

**تطبيق صغير بـ50 تحميل/نهار ≈ 0–5$/شهر.** التحميلات الكبيرة هي اللي كتكلّف (egress + CPU).

---

## ✅ Checklist قبل ما تنشر

- [ ] `ADMIN_PASSWORD` قوي (ماشي `admin123`)
- [ ] `SECRET_KEY` ثابت (ماشي عشوائي فكل restart)
- [ ] `--max-instances 1` (وإلا التحميلات كتطيح)
- [ ] `PUBLIC_BASE_URL` = الرابط النهائي
- [ ] جرّبت تحميل فيديو حقيقي بعد النشر
- [ ] راقبت اللوغ: `gcloud run logs tail ytultra`
- [ ] زدت `/sitemap.xml` فـ Google Search Console
- [ ] قريتي شروط Google Cloud + حقوق النشر (تحميل يوتيوب خارج التطبيق الرسمي كيخالف ToS فـ حالات)
