"""yt-dlp powered downloader with in-memory job progress + sqlite history."""
import os
import re
import shutil
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

import requests

import db

BASE_DIR = Path(__file__).resolve().parent
JOBS_DIR = Path(os.environ.get("JOBS_DIR", "/tmp/ytultra-jobs"))
JOBS_DIR.mkdir(parents=True, exist_ok=True)

YT_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtu.be", "www.youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com",
}
VID_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
JOBS: dict[str, dict] = {}
INFO_CACHE: dict[str, dict] = {}
CACHE_TTL = 600

try:
    import yt_dlp
except ImportError:  # pragma: no cover
    yt_dlp = None


def find_ffmpeg() -> str | None:
    local = BASE_DIR / "bin" / "ffmpeg"
    if local.exists() and os.access(local, os.X_OK):
        return str(local)
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which("ffmpeg")


FFMPEG = find_ffmpeg()


# ------------------------------ helpers ------------------------------
def human_size(n) -> str:
    if not n:
        return "—"
    n = float(n)
    for unit in ("o", "Ko", "Mo", "Go"):
        if n < 1024 or unit == "Go":
            return f"{n:.0f} {unit}" if unit == "o" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} Go"


def normalize_url(raw: str) -> str | None:
    if not raw:
        return None
    raw = raw.strip().strip("<>\"' ")
    if not raw.lower().startswith(("http://", "https://")):
        if VID_ID_RE.match(raw):
            return f"https://www.youtube.com/watch?v={raw}"
        return None
    try:
        host = (urlparse(raw).hostname or "").lower()
    except Exception:
        return None
    if host not in YT_HOSTS:
        return None
    return raw


def ydl_base_opts(extra: dict | None = None) -> dict:
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "skip_download": True,
        "nocheckcertificate": True,
        "socket_timeout": 20,
        "extractor_retries": 2,
        "retries": 2,
        "ffmpeg_location": FFMPEG,
        "http_headers": {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
            )
        },
    }
    if extra:
        opts.update(extra)
    return opts


def extract_info(url: str) -> dict:
    attempts = [None, ["tv"], ["android"], ["ios"], ["web_safari"]]
    last_err: Exception | None = None
    for client in attempts:
        extra: dict = {"skip_download": True}
        if client:
            extra["extractor_args"] = {"youtube": {"player_client": client}}
        try:
            with yt_dlp.YoutubeDL(ydl_base_opts(extra)) as ydl:
                return ydl.extract_info(url, download=False)
        except Exception as e:  # noqa: BLE001
            last_err = e
            msg = str(e)
            if any(k in msg for k in ("Private video", "Video unavailable", "Incomplete YouTube ID",
                                      "This video is unavailable", "members-only")):
                break
    raise last_err or RuntimeError("extract failed")


def est_size(f: dict, duration: float) -> int:
    size = f.get("filesize") or f.get("filesize_approx")
    if size:
        return int(size)
    tbr = f.get("tbr") or 0
    if tbr and duration:
        return int(tbr * 1000 / 8 * float(duration))
    return 0


def format_duration(sec: int) -> str:
    sec = int(sec or 0)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def build_payload(info: dict) -> dict:
    duration = info.get("duration") or 0
    heights: dict[int, dict] = {}
    audio_candidates: list[dict] = []

    for f in info.get("formats") or []:
        vcodec, acodec = f.get("vcodec"), f.get("acodec")
        if vcodec not in (None, "none") and f.get("height"):
            if f.get("ext") not in ("mp4", "webm"):
                continue
            h = int(f["height"])
            rank = (
                2 if f.get("ext") == "mp4" else 0,
                2 if "avc1" in (vcodec or "") else (1 if "hev" in (vcodec or "") else 0),
                1 if (f.get("fps") or 30) <= 30 else 0,
                f.get("tbr") or 0,
            )
            cur = heights.get(h)
            if cur is None or rank > cur["_rank"]:
                heights[h] = {"_rank": rank, "height": h, "fps": f.get("fps"),
                              "ext": f.get("ext"), "filesize": est_size(f, duration)}
        elif acodec not in (None, "none") and vcodec in (None, "none"):
            audio_candidates.append({"tbr": f.get("tbr") or 0, "filesize": est_size(f, duration)})

    best_audio = max(audio_candidates, key=lambda a: a["tbr"], default=None)
    best_audio_size = best_audio["filesize"] if best_audio else 0

    qualities = []
    for h in sorted(heights, reverse=True):
        q = heights[h]
        total = (q.get("filesize") or 0) + (best_audio_size or 0)
        label = {2160: "4K", 1440: "2K", 1080: "FHD", 720: "HD", 480: "SD"}.get(h, "SD")
        qualities.append({
            "height": h, "label": label,
            "fps": int(q["fps"]) if q.get("fps") else None,
            "ext": "MP4",
            "size": human_size(total) if total else None,
        })

    vid = info.get("id") or ""
    return {
        "id": vid,
        "title": info.get("title") or "Vidéo sans titre",
        "uploader": info.get("uploader") or info.get("channel") or "Chaîne inconnue",
        "duration": duration,
        "duration_str": format_duration(duration),
        "views": info.get("view_count") or 0,
        "upload_date": info.get("upload_date") or "",
        "thumbnail": f"/api/thumb/{vid}" if VID_ID_RE.match(vid) else (info.get("thumbnail") or ""),
        "webpage_url": info.get("webpage_url") or "",
        "is_live": bool(info.get("is_live")),
        "qualities": qualities,
    }


def get_info(url: str) -> dict:
    cached = INFO_CACHE.get(url)
    if cached and time.time() - cached["ts"] < CACHE_TTL:
        return cached["data"]
    payload = build_payload(extract_info(url))
    INFO_CACHE[url] = {"ts": time.time(), "data": payload}
    return payload


THUMB_QUALITIES = {"maxresdefault", "sddefault", "hqdefault", "mqdefault", "default"}


def fetch_thumb(vid: str, quality: str | None = None) -> bytes | None:
    if not VID_ID_RE.match(vid):
        return None
    order = [quality] if quality in THUMB_QUALITIES else ["maxresdefault", "sddefault", "hqdefault", "mqdefault"]
    for q in order:
        try:
            r = requests.get(f"https://i.ytimg.com/vi/{vid}/{q}.jpg", timeout=12,
                             headers={"User-Agent": "Mozilla/5.0"})
            if r.ok and len(r.content) > 1500:
                return r.content
        except Exception:
            continue
    return None


# ------------------------------ jobs ------------------------------
def start_job(url: str, kind: str, height: int, abr: int, slug: str = "") -> str:
    jid = uuid.uuid4().hex[:12]
    quality = f"{height}p" if kind == "video" else f"{abr}kbps"
    JOBS[jid] = {
        "id": jid, "status": "queued", "phase": "queued", "percent": 0.0,
        "speed": 0, "eta": None, "filename": None, "filesize": 0, "error": None,
        "created": time.time(), "title": "", "kind": kind,
    }
    db.log_job_start(jid, url, slug, kind, quality)
    threading.Thread(target=_run_job, args=(jid, url, kind, height, abr), daemon=True).start()
    return jid


def _run_job(jid: str, url: str, kind: str, height: int, abr: int):
    job = JOBS[jid]
    outdir = JOBS_DIR / jid
    outdir.mkdir(parents=True, exist_ok=True)
    files: dict[str, float] = {}

    def progress_hook(d):
        name = d.get("filename") or "f"
        if d.get("status") == "downloading":
            job["phase"] = "downloading"
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            got = d.get("downloaded_bytes") or 0
            files[name] = (got / total) if total else 0.0
            expected = 1 if kind == "audio" else 2
            frac = min(sum(files.values()) / max(expected, len(files)), 0.999)
            job["percent"] = round(frac * (96 if kind == "video" else 92), 1)
            job["speed"] = d.get("speed") or 0
            job["eta"] = d.get("eta")
        elif d.get("status") == "finished":
            files[name] = 1.0
            job["phase"] = "merging" if kind == "video" else "converting"
            job["percent"] = max(job["percent"], 96 if kind == "video" else 92)
            job["speed"] = 0
            job["eta"] = None

    def pp_hook(d):
        if d.get("status") == "started":
            job["phase"] = "merging" if kind == "video" else "converting"
            job["percent"] = max(job["percent"], 97 if kind == "video" else 94)
        elif d.get("status") == "finished":
            job["percent"] = 99.0

    opts = ydl_base_opts({
        "skip_download": False,
        "outtmpl": str(outdir / "%(title).90B [%(id)s].%(ext)s"),
        "progress_hooks": [progress_hook],
        "postprocessor_hooks": [pp_hook],
        "concurrent_fragment_downloads": 4,
        "overwrites": True,
        "quiet": True,
    })

    if kind == "audio":
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": str(abr),
        }]
    else:
        h = height or 1080
        opts["format"] = (
            f"bv*[height<={h}][ext=mp4]+ba[ext=m4a]/bv*[height<={h}]+ba/"
            f"b[height<={h}]/bv*+ba/b"
        )
        opts["merge_output_format"] = "mp4"

    try:
        job["status"] = "running"
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            job["title"] = (info or {}).get("title") or ""

        candidates = [
            p for p in outdir.iterdir()
            if p.is_file() and p.suffix.lower() in (".mp4", ".mkv", ".webm", ".mp3", ".m4a")
            and not p.name.endswith(".part")
        ]
        if not candidates:
            raise RuntimeError("Fichier introuvable après téléchargement")
        f = max(candidates, key=lambda p: p.stat().st_size)
        if kind == "audio" and f.suffix.lower() != ".mp3":
            target = f.with_suffix(".mp3")
            try:
                f.replace(target)
                f = target
            except Exception:
                pass
        job.update({
            "filename": f.name, "filesize": f.stat().st_size,
            "size_str": human_size(f.stat().st_size),
            "percent": 100.0, "status": "ready", "phase": "ready", "speed": 0, "eta": 0,
        })
        db.log_job_finish(jid, "ready", f.stat().st_size, f.name, job["title"])
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if "Private video" in msg:
            err = "Cette vidéo est privée, elle ne peut pas être téléchargée."
        elif "age" in msg.lower() and "restrict" in msg.lower():
            err = "Cette vidéo est réservée aux adultes, YouTube bloque le téléchargement."
        elif "Unsupported URL" in msg:
            err = "Ce lien n'est pas pris en charge."
        else:
            err = "Une erreur est survenue pendant le téléchargement. Réessayez."
        job.update({"status": "error", "phase": "error", "error": err})
        db.log_job_finish(jid, "error")
        shutil.rmtree(outdir, ignore_errors=True)


def get_job(jid: str) -> dict | None:
    return JOBS.get(jid)


def file_path(jid: str) -> Path | None:
    job = JOBS.get(jid)
    if not job or job["status"] != "ready":
        return None
    p = JOBS_DIR / jid / job["filename"]
    return p if p.exists() else None


def cleanup_loop():
    while True:
        time.sleep(900)
        now = time.time()
        for jid, job in list(JOBS.items()):
            if now - job.get("created", now) > 3600:
                shutil.rmtree(JOBS_DIR / jid, ignore_errors=True)
                JOBS.pop(jid, None)
        for p in JOBS_DIR.iterdir():
            try:
                if p.is_dir() and now - p.stat().st_mtime > 3600:
                    shutil.rmtree(p, ignore_errors=True)
            except Exception:
                pass


threading.Thread(target=cleanup_loop, daemon=True).start()
