"""Programmatic SEO engine — builds dozens of unique, internally-linked landing pages."""
from hashlib import md5

BRAND = "ytultra"


def _pick(seq, seed):
    return seq[int(md5(seed.encode()).hexdigest(), 16) % len(seq)]


# ─────────────────────────────── data ───────────────────────────────
FORMATS = {
    "mp3": dict(label="MP3", family="audio", codec="MPEG-1 Layer III", badge="Audio",
                blurb="Le format audio universel : petit, compatible partout, parfait pour la musique et les podcasts.",
                pros=["Fichiers légers, jusqu'à 10× plus petits qu'une vidéo", "Compatible avec tous les lecteurs et smartphones",
                      "Qualité réglable : 128, 192 ou 320 kbps"],
                uses=["Écouter dans la voiture ou en course", "Alimenter une bibliothèque musicale hors ligne", "Extraire la voix d'une conférence"]),
    "mp4": dict(label="MP4", family="vidéo", codec="H.264 + AAC", badge="Vidéo",
                blurb="Le format vidéo standard : lecture instantanée sur iPhone, Android, Windows, Mac et smart TV.",
                pros=["Lisible nativement partout, sans codec supplémentaire", "Conserve la vidéo et l'audio synchronisés",
                      "Compatible avec iMovie, Premiere et CapCut"],
                uses=["Archiver une vidéo pour la regarder hors ligne", "Réutiliser un extrait dans un montage", "Partager sur WhatsApp ou Telegram"]),
    "webm": dict(label="WEBM", family="vidéo", codec="VP9 / Opus", badge="Vidéo",
                 blurb="Format web ouvert, souvent plus léger que le MP4 à qualité visuelle égale.",
                 pros=["Compression efficace pour le web", "Codecs libres (VP9, Opus)", "Idéal pour les intégrations HTML5"],
                 uses=["Intégrer une vidéo dans un site", "Économiser de l'espace disque", "Travailler dans des outils open source"]),
    "m4a": dict(label="M4A", family="audio", codec="AAC", badge="Audio",
                blurb="Audio AAC encapsulé dans un conteneur MP4 : la meilleure qualité à petit poids sur Apple.",
                pros=["Meilleure qualité que le MP3 à débit égal", "Gestion native par iOS et iTunes", "Parfait pour les podcasts"],
                uses=["Podcasts sur iPhone", "Sons de notification et voix off", "Bibliothèque Apple Music locale"]),
    "wav": dict(label="WAV", family="audio", codec="PCM non compressé", badge="Audio",
                blurb="Audio brut sans perte : la référence en studio pour le montage et la restauration.",
                pros=["Aucune perte de qualité", "Compatible avec tous les DAW", "Support natif Windows et macOS"],
                uses=["Montage audio professionnel", "Analyse du signal", "Échantillonnage pour la production"]),
    "flac": dict(label="FLAC", family="audio", codec="Sans perte compressé", badge="Audio",
                 blurb="Compression sans perte : la qualité du WAV avec deux fois moins d'espace.",
                 pros=["Bit-perfect, aucune perte", "Métadonnées complètes", "Idéal pour l'archivage musical"],
                 uses=["Collection hi-fi", "Archives long terme", "Écoute sur lecteurs audiophiles"]),
    "aac": dict(label="AAC", family="audio", codec="Advanced Audio Coding", badge="Audio",
                blurb="Le codec audio moderne d'Apple et YouTube : plus efficient que le MP3.",
                pros=["Meilleur rendu à bas débit", "Standard sur iOS et les TV", "Fichiers compacts"],
                uses=["Streaming local", "Podcasts", "Sons d'application"]),
    "ogg": dict(label="OGG", family="audio", codec="Vorbis", badge="Audio",
                blurb="Format audio libre, sans licence, très apprécié sous Linux et dans les jeux.",
                pros=["100 % libre de droits", "Bonne qualité à bas débit", "Support dans Firefox et VLC"],
                uses=["Jeux et applications", "Systèmes Linux", "Distribution libre"]),
    "avi": dict(label="AVI", family="vidéo", codec="Conteneur historique", badge="Vidéo",
                blurb="Le conteneur classique, encore utile pour d'anciens lecteurs et téléviseurs.",
                pros=["Compatible avec les vieux appareils", "Simple à produire", "Lecture universelle sur PC"],
                uses=["Lecteurs DVD et TV anciens", "Archives personnelles", "Compatibilité maximale"]),
    "mov": dict(label="MOV", family="vidéo", codec="QuickTime", badge="Vidéo",
                blurb="Le format natif d'Apple : parfait pour Final Cut, iMovie et l'écosystème macOS.",
                pros=["Natif sur macOS et iOS", "Excellente qualité", "Pratique pour les workflows Apple"],
                uses=["Montage sur Final Cut Pro", "Tournages iPhone", "Projets iMovie"]),
    "mkv": dict(label="MKV", family="vidéo", codec="Matroska", badge="Vidéo",
                blurb="Conteneur flexible capable d'accueillir plusieurs pistes audio et sous-titres.",
                pros=["Multi-pistes audio et sous-titres", "Toutes résolutions, jusqu'à la 4K", "Compression efficace"],
                uses=["Archivage de films", "Séries multilingues", "Collections 4K"]),
    "3gp": dict(label="3GP", family="vidéo", codec="H.263", badge="Vidéo",
                blurb="Le format ultra-léger des téléphones anciens, idéal quand l'espace est compté.",
                pros=["Fichiers minuscules", "Compatible avec les feature phones", "Téléchargement très rapide"],
                uses=["Téléphones anciens", "Réseaux 2G/3G", "Stockage limité"]),
}

QUALITIES = {
    "144p": dict(h=144, name="144p", tier="Très basse", blurb="La plus petite taille possible : quelques Mo pour une vidéo entière.",
                 use="Connexions lentes et stockage très limité"),
    "240p": dict(h=240, name="240p", tier="Basse", blurb="Un compromis minimal entre lisibilité et poids du fichier.",
                 use="Mémorisation sur montres et vieux appareils"),
    "360p": dict(h=360, name="360p", tier="Standard", blurb="La définition SD classique, suffisante pour un écran de téléphone.",
                 use="Économiser de la data mobile"),
    "480p": dict(h=480, name="480p", tier="SD", blurb="Meilleure netteté que la 360p sans exploser le poids.",
                 use="Tablettes et petits écrans"),
    "720p": dict(h=720, name="720p", tier="HD", blurb="La HD d'entrée de gamme : nette, légère, universelle.",
                 use="Regarder sur laptop ou TV 720p"),
    "1080p": dict(h=1080, name="1080p", tier="Full HD", blurb="Le meilleur rapport netteté / taille pour 95 % des usages.",
                 use="TV Full HD, montage simple, archivage"),
    "1440p": dict(h=1440, name="1440p", tier="2K", blurb="Deux fois plus de pixels que la Full HD, pour les grands écrans.",
                 use="Moniteurs QHD et recadrage en montage"),
    "2160p": dict(h=2160, name="2160p", tier="4K Ultra HD", blurb="La résolution maximale proposée par YouTube.",
                 use="TV 4K, projection et mastering"),
}

DEVICES = {
    "iphone": dict(name="iPhone", os="iOS", tip="Enregistrez le fichier dans Fichiers puis ouvrez-le depuis Photos ou VLC."),
    "android": dict(name="Android", os="Android", tip="Le fichier arrive dans Téléchargements ; ouvrez-le avec Google Photos ou VLC."),
    "ipad": dict(name="iPad", os="iPadOS", tip="Utilisez l'app Fichiers pour retrouver la vidéo et la lire hors connexion."),
    "windows": dict(name="Windows", os="Windows 10/11", tip="Le fichier se place dans Téléchargements, prêt pour VLC ou Films & TV."),
    "mac": dict(name="Mac", os="macOS", tip="Le fichier arrive dans Téléchargements ; ouvrez-le avec QuickTime ou VLC."),
    "linux": dict(name="Linux", os="Ubuntu, Fedora, Debian", tip="Téléchargez puis lisez avec VLC, mpv ou votre lecteur habituel."),
    "smart-tv": dict(name="Smart TV", os="Android TV, Samsung, LG", tip="Téléchargez sur ordinateur puis envoyez sur la TV par USB ou DLNA."),
}

AUDIENCES = {
    "etudiants": dict(name="étudiants", text="cours en ligne, conférences et tutoriels",
                      why="Réviser hors connexion dans le train ou entre deux cours, sans dépendre du Wi-Fi du campus."),
    "createurs": dict(name="créateurs de contenu", text="références, inspirations et formats viraux",
                      why="Constituer une banque de références et analyser le montage des vidéos qui performent."),
    "chercheurs": dict(name="chercheurs", text="interventions, colloques et archives",
                       why="Archiver des sources audiovisuelles citables et les analyser hors ligne."),
    "professeurs": dict(name="professeurs", text="capsules pédagogiques et documentaires",
                        why="Préparer des supports de cours utilisables sans connexion en classe."),
    "monteurs": dict(name="monteurs vidéo", text="rushes, bandes-annonces et extraits",
                     why="Récupérer des médias dans la meilleure qualité disponible avant montage."),
    "podcasteurs": dict(name="podcasteurs", text="interviews et épisodes audio",
                        why="Extraire la piste audio en MP3 propre pour la réutiliser en podcast."),
}

CONTENT = {
    "youtube-shorts": dict(name="Shorts", h1="Télécharger des vidéos YouTube Shorts",
                           blurb="Les Shorts sont verticaux, courts et souvent impossibles à enregistrer depuis l'app mobile. Collez leur lien et récupérez-les en MP4 vertical.",
                           tips=["Le format vertical est conservé (1080×1920)", "Idéal pour analyser un trend ou garder une référence",
                                 "Fonctionne avec les liens /shorts/ et youtu.be"]),
    "youtube-music": dict(name="YouTube Music", h1="Télécharger la musique de YouTube Music",
                          blurb="Convertissez un morceau ou une session live en MP3 ou M4A, avec les métadonnées du titre.",
                          tips=["Sortie MP3 jusqu'à 320 kbps", "Parfait pour une playlist hors connexion",
                                "Compatible avec les liens music.youtube.com"]),
    "youtube-live": dict(name="YouTube Live", h1="Télécharger un direct YouTube",
                         blurb="Enregistrez une conférence en direct, un concert ou un stream terminé, dans la qualité choisie.",
                         tips=["Fonctionne aussi sur les rediffusions", "La durée du direct détermine le poids final",
                               "Le fichier est prêt dès la fin du traitement"]),
    "telecharger-chaine-youtube": dict(name="chaînes YouTube", h1="Sauvegarder les vidéos d'une chaîne",
                                       blurb="Copiez le lien d'une vidéo de la chaîne, choisissez la qualité et constituez votre archive.",
                                       tips=["Une vidéo à la fois : contrôlez la qualité", "Bon réflexe avant une suppression définitive",
                                             "Utile pour les chaînes éducatives"]),
}

INTENTS = {
    "telecharger-video-youtube-sans-logiciel": dict(
        h1="Télécharger une vidéo YouTube sans logiciel",
        kicker="100 % NAVIGATEUR",
        blurb="Aucune installation, aucun plugin : collez le lien et le fichier arrive dans votre dossier de téléchargements.",
        benefits=[("globe", "Rien à installer", "Le téléchargement se fait entièrement dans le navigateur, sur ordinateur comme sur mobile."),
                  ("shield", "Aucune extension", "Pas de module tiers à autoriser : votre navigateur reste propre."),
                  ("zap", "Prêt immédiatement", "La conversion démarre dès le clic, sans file d'attente ni inscription."),
                  ("download", "Fichier standard", "Vous récupérez un MP4 ou MP3 lisible par tous vos appareils.")]),
    "telecharger-video-youtube-sans-inscription": dict(
        h1="Télécharger une vidéo YouTube sans inscription",
        kicker="SANS COMPTE",
        blurb="Pas d'email, pas de compte, pas de mot de passe. L'outil fonctionne immédiatement, anonymement.",
        benefits=[("lock", "Zéro compte", "Aucun formulaire d'inscription avant de lancer le téléchargement."),
                  ("shield", "Vie privée respectée", "Aucune donnée personnelle demandée pour convertir une vidéo."),
                  ("zap", "Accès instantané", "Ouvrez la page, collez le lien, c'est tout."),
                  ("check", "Gratuit", "Toutes les qualités sont accessibles sans abonnement.")]),
    "telecharger-video-youtube-en-ligne": dict(
        h1="Télécharger une vidéo YouTube en ligne",
        kicker="OUTIL EN LIGNE",
        blurb="Un service web 100 % en ligne, utilisable depuis n'importe quel navigateur et n'importe quel appareil.",
        benefits=[("globe", "Multi-plateforme", "Windows, macOS, Linux, iOS, Android : même expérience partout."),
                  ("zap", "Sans attente", "Analyse de l'URL en quelques secondes seulement."),
                  ("layers", "Toutes les qualités", "De la 144p à la 4K, plus l'extraction audio MP3."),
                  ("lock", "Sans logiciel", "Rien à télécharger pour commencer.")]),
    "telecharger-video-youtube-gratuit": dict(
        h1="Télécharger des vidéos YouTube gratuitement",
        kicker="GRATUIT",
        blurb="Toutes les fonctionnalités essentielles sont gratuites : aucune limite cachée, aucune carte bancaire.",
        benefits=[("check", "100 % gratuit", "Le service ne demande ni paiement ni abonnement."),
                  ("download", "Qualité maximale", "La 4K n'est pas réservée à une offre payante."),
                  ("zap", "Sans publicité intrusive", "Une interface claire, sans pop-ups qui bloquent le téléchargement."),
                  ("shield", "Sans risque", "Aucune installation, donc aucun programme indésirable.")]),
    "telecharger-video-youtube-sans-publicite": dict(
        h1="Télécharger une vidéo YouTube sans publicité",
        kicker="SANS PUB",
        blurb="Une page propre : pas de pop-ups, pas de redirections, pas de faux boutons.",
        benefits=[("shield", "Zéro pop-up", "Le bouton de téléchargement est toujours celui que vous croyez."),
                  ("zap", "Parcours direct", "Lien → qualité → fichier, en trois clics."),
                  ("lock", "Aucun traqueur tiers", "Pas de régies publicitaires sur les pages de téléchargement."),
                  ("check", "Interface sobre", "Un design lisible, sans distraction.")]),
    "telecharger-video-youtube-rapide": dict(
        h1="Télécharger une vidéo YouTube rapidement",
        kicker="RAPIDE",
        blurb="Les téléchargements parallèles et le traitement serveur réduisent l'attente au strict minimum.",
        benefits=[("zap", "Démarrage immédiat", "L'analyse de la vidéo prend quelques secondes."),
                  ("layers", "Téléchargement parallèle", "Les segments de la vidéo sont récupérés simultanément."),
                  ("download", "Prêt à l'emploi", "Fichier fusionné automatiquement, sans étape manuelle."),
                  ("check", "Toutes qualités", "Même principe en 144p qu'en 4K.")]),
    "convertisseur-youtube": dict(
        h1="Convertisseur YouTube en MP4 et MP3",
        kicker="CONVERTISSEUR",
        blurb="Un seul outil pour convertir une vidéo YouTube vers le format dont vous avez besoin, sans perte inutile.",
        benefits=[("layers", "12 formats", "MP4, MP3, WEBM, M4A, WAV, FLAC, AAC, OGG, AVI, MOV, MKV, 3GP."),
                  ("music", "Audio haute qualité", "Extraction MP3 jusqu'à 320 kbps."),
                  ("film", "Vidéo jusqu'à 4K", "Conservez la résolution maximale de la source."),
                  ("zap", "Sans file d'attente", "Conversion lancée instantanément.")]),
    "telecharger-miniature-youtube": dict(
        h1="Télécharger la miniature d'une vidéo YouTube",
        kicker="MINIATURES",
        blurb="Récupérez la vignette officielle d'une vidéo en haute résolution (maxres 1280×720, HQ 480×360).",
        benefits=[("image", "Haute résolution", "La miniature maxresdefault dès qu'elle existe."),
                  ("zap", "Instantané", "Aucun traitement : lien direct vers l'image."),
                  ("download", "Tous formats", "Téléchargez en JPG, HD ou SD selon vos besoins."),
                  ("check", "Sans compte", "Collez le lien, récupérez l'image.")],
        tool="thumbnail"),
}

# ───────────────────────── copy helpers ─────────────────────────
LEADS = [
    "Collez l'URL de la vidéo, choisissez la qualité et récupérez votre fichier en quelques secondes — sans inscription, sans logiciel.",
    "Un outil simple et rapide : le lien de la vidéo suffit pour obtenir un fichier prêt à l'emploi.",
    "De l'URL au fichier en trois étapes. Toutes les qualités disponibles, un seul clic.",
]

FMT_LEADS = [
    "Convertissez n'importe quelle vidéo YouTube en {label} avec la qualité de votre choix, directement depuis votre navigateur.",
    "Obtenez un fichier {label} ({codec}) à partir de n'importe quel lien YouTube, sans installation.",
    "YouTube vers {label} en quelques secondes : collez le lien et choisissez la résolution avant de lancer la conversion.",
]

Q_LEADS = [
    "Téléchargez vos vidéos YouTube en {name} ({tier}) : des fichiers plus légers, prêts pour {use}.",
    "La qualité {name} est disponible pour toutes les vidéos : idéale pour {use}.",
    "Choisissez la {name} pour un bon équilibre entre netteté, poids et vitesse de téléchargement.",
]

FMT_INTRO = [
    "Le {label} est {blurb_lower} Notre outil extrait le flux d'origine de YouTube puis le prépare dans ce conteneur, en conservant {codec}.",
    "{blurb} Le convertisseur s'occupe du reste : sélection du flux le plus adapté, fusion et export dans le bon format.",
]

Q_INTRO = [
    "La définition {name} correspond à une image de {w} pixels de large. {blurb} Sur YouTube, ce niveau est disponible sur la majorité des vidéos récentes.",
    "{blurb} Choisir explicitement la {name} évite de télécharger un fichier plus lourd que nécessaire quand on cible {use_lower}.",
]

FAQ_GENERIC = {
    "free": ("Est-ce gratuit ?", "Oui. Le téléchargement et la conversion sont gratuits, sans création de compte ni carte bancaire."),
    "safe": ("Est-ce légal ?", "Télécharger une vidéo ne doit servir qu'à un usage personnel : aucun contenu protégé ne doit être redistribué. Vérifiez les conditions d'utilisation de YouTube et les droits du créateur."),
    "quality": ("Quelle est la meilleure qualité disponible ?", "L'outil liste la résolution maximale réellement proposée par la vidéo : 4K, 2K, Full HD, HD ou SD. Il ne peut pas dépasser la qualité de la source."),
    "device": ("Cela fonctionne-t-il sur mobile ?", "Oui, la page est responsive et fonctionne dans Safari sur iPhone comme dans Chrome sur Android. Le fichier est enregistré dans vos téléchargements."),
    "speed": ("Combien de temps prend le téléchargement ?", "Quelques secondes pour une vidéo courte, davantage pour un long fichier 4K. La vitesse dépend surtout de votre connexion et de la taille du fichier."),
    "account": ("Faut-il un compte YouTube ?", "Non. Un lien public suffit. Les vidéos privées ou réservées aux membres d'une chaîne ne peuvent pas être téléchargées."),
}


def _faq(*keys):
    return [{"q": FAQ_GENERIC[k][0], "a": FAQ_GENERIC[k][1]} for k in keys]


def _related(slug, candidates, extra=()):
    out = [s for s in candidates if s != slug][:4]
    for e in extra:
        if e != slug and e not in out:
            out.append(e)
    return out[:6]


# ───────────────────────── page builders ─────────────────────────
def build_pages() -> dict[str, dict]:
    pages: dict[str, dict] = {}
    hub_related = ["youtube-mp3", "youtube-mp4", "youtube-1080p", "youtube-shorts", "convertisseur-youtube"]

    # ---- format pages ----
    for ext, f in FORMATS.items():
        slug = f"youtube-{ext}" if ext in ("mp3", "mp4") else f"youtube-en-{ext}"
        label = f["label"]
        pages[slug] = {
            "slug": slug, "kind": "format", "format": ext,
            "kicker": f"CONVERTISSEUR {label}",
            "h1": f"Télécharger une vidéo YouTube en {label}",
            "title": f"Télécharger YouTube en {label} — convertisseur {label} gratuit | {BRAND}",
            "description": f"Convertissez et téléchargez n'importe quelle vidéo YouTube en {label} ({f['codec']}). "
                           f"Gratuit, sans inscription, toutes qualités jusqu'à la 4K.",
            "lead": _pick(FMT_LEADS, slug).format(label=label, codec=f["codec"]),
            "intro": [
                _pick(FMT_INTRO, slug + "a").format(label=label, blurb=f["blurb"],
                                                 blurb_lower=f["blurb"][0].lower() + f["blurb"][1:],
                                                 codec=f["codec"]),
                f"Le résultat est un fichier {label} propre, lisible sur {', '.join(DEVICES[d]['name'] for d in ('windows', 'android', 'iphone', 'mac'))}. "
                f"Vous pouvez le garder hors connexion, l'importer dans un logiciel de montage ou l'envoyer à vos proches.",
            ],
            "benefits": [
                ("film" if f["family"] == "vidéo" else "music",
                 f"Sortie {label} native",
                 f"Le fichier final porte la bonne extension {ext.upper()} et le bon codec ({f['codec']})."),
                ("layers", f"Qualité {f['family']} préservée", f["pros"][0]),
                ("zap", "Conversion immédiate", "L'extraction et la conversion démarrent dès le clic, sans file d'attente."),
                ("check", "Sans logiciel", "Tout se passe dans le navigateur : aucune installation, aucune extension."),
            ],
            "steps": [
                {"title": "Copiez le lien de la vidéo", "text": "Depuis YouTube, utilisez le bouton Partager ou copiez l'URL de la barre d'adresse."},
                {"title": "Choisissez la qualité", "text": f"Sélectionnez la résolution souhaitée. L'outil prépare ensuite le fichier {label} à partir du meilleur flux disponible."},
                {"title": "Téléchargez votre fichier", "text": f"Le fichier {ext.upper()} est généré puis enregistré automatiquement sur votre appareil."},
            ],
            "extra_title": f"Quand utiliser le format {label} ?",
            "extra": f["uses"] + [f"Conserver une trace de la vidéo pour un usage personnel", f"Travailler hors connexion sans dépendre de YouTube"],
            "faq": _faq("free", "quality", "device", "safe"),
            "related": _related(slug, [s for s in pages if pages[s]["kind"] == "format"] or [slug], hub_related),
            "priority": 0.9 if ext in ("mp3", "mp4") else 0.7,
        }

    # ---- quality pages ----
    for key, q in QUALITIES.items():
        slug = f"youtube-{key}"
        pages[slug] = {
            "slug": slug, "kind": "quality", "height": q["h"],
            "kicker": f"TÉLÉCHARGEMENT {q['name'].upper()}",
            "h1": f"Télécharger une vidéo YouTube en {q['name']}",
            "title": f"Télécharger YouTube en {q['name']} — vidéo {q['tier']} | {BRAND}",
            "description": f"Téléchargez n'importe quelle vidéo YouTube en {q['name']} ({q['tier']}) en MP4. "
                           f"Idéal pour {q['use'].lower()}. Gratuit et sans inscription.",
            "lead": _pick(Q_LEADS, slug).format(name=q["name"], tier=q["tier"], use=q["use"].lower()),
            "intro": [
                _pick(Q_INTRO, slug + "b").format(name=q["name"], w=int(q["h"] * 16 / 9), blurb=q["blurb"], use_lower=q["use"].lower()),
                f"La {q['name']} reste l'un des meilleurs choix pour {q['use'].lower()}. "
                f"Notre convertisseur sélectionne automatiquement le flux vidéo correspondant puis le fusionne avec la meilleure piste audio.",
            ],
            "benefits": [
                ("film", f"Résolution {q['name']}", f"Fichier MP4 en {int(q['h']*16/9)}×{q['h']} pixels, sans dépasser la qualité de la source."),
                ("download", "Poids maîtrisé", f"Un fichier {q['tier'].lower()} pèse nettement moins qu'une version 4K équivalente."),
                ("zap", "Traitement rapide", "Moins de données à récupérer, donc un téléchargement plus court."),
                ("check", "Audio inclus", "La piste audio est fusionnée automatiquement dans le fichier final."),
            ],
            "steps": [
                {"title": "Collez l'URL de la vidéo", "text": "Le champ accepte les liens watch, youtu.be et shorts."},
                {"title": f"Sélectionnez {q['name']}", "text": "Choisissez la définition dans la liste des qualités proposées pour cette vidéo."},
                {"title": "Récupérez le fichier", "text": "Le MP4 est fusionné puis téléchargé sur votre appareil."},
            ],
            "extra_title": f"Pourquoi choisir la {q['name']} ?",
            "extra": [f"Adapté à {q['use'].lower()}", "Bon compromis entre netteté et espace disque",
                      "Lecture fluide sur les appareils modestes", "Téléchargement plus rapide qu'en 4K",
                      "Compatible avec tous les lecteurs vidéo"],
            "faq": _faq("quality", "speed", "free", "device"),
            "related": _related(slug, [s for s in pages if pages[s].get("kind") == "quality"] + ["youtube-mp4", "youtube-2160p", "youtube-1080p"], hub_related),
            "priority": 0.8 if q["h"] in (1080, 2160, 720) else 0.6,
        }

    # ---- device pages ----
    for key, d in DEVICES.items():
        slug = f"telecharger-youtube-sur-{key}"
        pages[slug] = {
            "slug": slug, "kind": "device", "device": key,
            "kicker": f"SUR {d['name'].upper()}",
            "h1": f"Télécharger une vidéo YouTube sur {d['name']}",
            "title": f"Télécharger une vidéo YouTube sur {d['name']} ({d['os']}) | {BRAND}",
            "description": f"Comment télécharger une vidéo YouTube sur {d['name']} en MP4 ou MP3 : méthode sans application, "
                           f"toutes qualités, gratuite et immédiate.",
            "lead": f"Sur {d['name']} ({d['os']}), aucun magasin d'applications n'est nécessaire : tout se passe dans le navigateur.",
            "intro": [
                f"Depuis {d['name']}, ouvrez le navigateur, collez le lien de la vidéo YouTube et lancez le téléchargement. "
                f"Le fichier est préparé côté serveur puis enregistré dans le stockage de l'appareil.",
                f"{d['tip']} La procédure est identique pour un MP4 en 1080p, une vidéo 4K ou un fichier audio MP3."
            ],
            "benefits": [
                ("smartphone" if key in ("iphone", "android") else "monitor", f"Optimisé {d['name']}", "Interface responsive qui s'adapte à l'écran et au navigateur."),
                ("zap", "Sans application", "Aucun store, aucune autorisation système à accorder."),
                ("download", "Enregistrement direct", "Le fichier arrive dans le dossier de téléchargements standard."),
                ("layers", "Toutes les qualités", "De la 144p à la 4K selon ce que propose la vidéo."),
            ],
            "steps": [
                {"title": "Ouvrez YouTube", "text": f"Dans l'application ou le navigateur de votre {d['name']}, copiez le lien de la vidéo."},
                {"title": "Collez le lien ici", "text": "Le champ d'analyse accepte tous les formats d'URL YouTube."},
                {"title": "Choisissez et téléchargez", "text": f"Sélectionnez la qualité puis enregistrez le fichier. {d['tip']}"},
            ],
            "extra_title": f"Bon à savoir sur {d['name']}",
            "extra": ["Aucun compte ni abonnement requis", "Fonctionne en Wi-Fi comme en 4G/5G",
                      "Les fichiers restent lisibles hors connexion", "Compatible avec VLC et les lecteurs natifs",
                      "Supprime automatiquement les fichiers temporaires"],
            "faq": _faq("device", "free", "speed", "safe"),
            "related": _related(slug, [s for s in pages if pages[s].get("kind") == "device"] + ["youtube-mp3", "youtube-1080p", "youtube-shorts"], hub_related),
            "priority": 0.65,
        }

    # ---- audience pages ----
    for key, a in AUDIENCES.items():
        slug = f"youtube-pour-{key}"
        pages[slug] = {
            "slug": slug, "kind": "audience", "audience": key,
            "kicker": "CAS D'USAGE",
            "h1": f"Télécharger des vidéos YouTube pour les {a['name']}",
            "title": f"Téléchargement YouTube pour les {a['name']} — MP4 & MP3 | {BRAND}",
            "description": f"Un outil pensé pour les {a['name']} : récupérez {a['text']} en MP4 ou MP3, "
                           f"hors connexion et en haute qualité.",
            "lead": f"Parce que les {a['name']} ont besoin de {a['text']} sans dépendre du réseau, ytultra simplifie la récupération des fichiers.",
            "intro": [
                f"Les {a['name']} utilisent YouTube au quotidien pour {a['text']}. Tout garder en ligne n'est pas toujours possible : "
                f"une connexion qui saute, un déplacement, une salle sans Wi-Fi.",
                f"C'est là que le téléchargement local devient utile : {a['why']} Le fichier obtenu reste lisible sur tous les appareils, sans publicité.",
            ],
            "benefits": [
                ("graduation" if key in ("etudiants", "professeurs", "chercheurs") else "users", f"Pensé pour les {a['name']}", f"Un parcours court, sans jargon technique, pour récupérer {a['text']}."),
                ("zap", "Hors connexion", "Travaillez ou révisez sans dépendre de la qualité du réseau."),
                ("music", "Audio séparé", "Extrayez la piste MP3 quand seule la voix ou la musique vous intéresse."),
                ("shield", "Usage personnel", "Les fichiers restent privés, stockés sur votre appareil."),
            ],
            "steps": [
                {"title": "Rassemblez vos liens", "text": "Copiez les URL des vidéos utiles depuis YouTube, une par une."},
                {"title": "Analysez et choisissez", "text": "La page affiche les qualités disponibles et le poids estimé de chaque fichier."},
                {"title": "Téléchargez et classez", "text": "Enregistrez les fichiers dans un dossier dédié pour les retrouver facilement."},
            ],
            "extra_title": "Trois conseils pratiques",
            "extra": ["Privilégiez la 720p ou 1080p pour un bon équilibre poids / netteté",
                      "Extrayez l'audio MP3 pour les contenus essentiellement parlés",
                      "Organisez vos fichiers par sujet ou par projet dès le téléchargement",
                      "Vérifiez toujours les droits avant de réutiliser un contenu",
                      "Nommez vos fichiers pour les retrouver plus tard"],
            "faq": _faq("free", "device", "quality", "safe"),
            "related": _related(slug, [s for s in pages if pages[s].get("kind") == "audience"] + ["youtube-mp3", "youtube-720p", "youtube-shorts"], hub_related),
            "priority": 0.6,
        }

    # ---- content type pages ----
    for key, c in CONTENT.items():
        slug = key
        pages[slug] = {
            "slug": slug, "kind": "content", "content": key,
            "kicker": "TYPE DE CONTENU",
            "h1": c["h1"],
            "title": f"{c['h1']} — gratuit et sans inscription | {BRAND}",
            "description": f"{c['blurb'][:150]} Téléchargement gratuit, sans compte, en MP4 ou MP3.",
            "lead": c["blurb"],
            "intro": [
                c["blurb"],
                "L'outil accepte tous les formats de liens YouTube : youtube.com/watch, youtu.be, /shorts/ et music.youtube.com. "
                "La qualité proposée dépend uniquement de la source : certaines vidéos plafonnent en 1080p, d'autres montent jusqu'à la 4K.",
            ],
            "benefits": [
                ("film", "MP4 ou MP3", "Choisissez la vidéo complète ou seulement la piste audio."),
                ("layers", "Qualité maximale", "L'outil sélectionne le meilleur flux disponible pour ce contenu."),
                ("zap", "Sans attente", "Analyse et téléchargement démarrent immédiatement."),
                ("check", "Liens acceptés", "Watch, youtu.be, shorts et music.youtube.com."),
            ],
            "steps": [
                {"title": "Copiez le lien", "text": f"Depuis YouTube, partagez le {c['name']} et copiez son URL."},
                {"title": "Collez dans le champ", "text": "L'analyse récupère le titre, la durée et les qualités disponibles."},
                {"title": "Téléchargez", "text": "Choisissez le format puis enregistrez le fichier sur votre appareil."},
            ],
            "extra_title": "Points importants",
            "extra": c["tips"] + ["Aucune inscription requise", "Fichiers supprimés automatiquement du serveur"],
            "faq": _faq("quality", "free", "safe", "device"),
            "related": _related(slug, [s for s in pages if pages[s].get("kind") == "content"] + ["youtube-mp4", "youtube-mp3"], hub_related),
            "priority": 0.85 if key == "youtube-shorts" else 0.7,
        }

    # ---- intent pages ----
    for slug, i in INTENTS.items():
        pages[slug] = {
            "slug": slug, "kind": "intent",
            "tool": i.get("tool"),
            "kicker": i["kicker"],
            "h1": i["h1"],
            "title": f"{i['h1']} — gratuit, MP4 & MP3 | {BRAND}",
            "description": i["blurb"][:158],
            "lead": i["blurb"],
            "intro": [
                i["blurb"],
                "Toutes les qualités réellement proposées par la vidéo sont accessibles : 4K, 2K, Full HD, HD ou SD, "
                "ainsi que l'extraction audio MP3 jusqu'à 320 kbps. Le fichier est préparé côté serveur puis enregistré "
                "directement dans votre dossier de téléchargements.",
            ],
            "benefits": [(icon, t, x) for icon, t, x in i["benefits"]],
            "steps": [
                {"title": "Copiez l'URL YouTube", "text": "Un lien public suffit : watch, youtu.be ou shorts."},
                {"title": "Choisissez le format et la qualité", "text": "Vidéo MP4 jusqu'à la 4K ou audio MP3 jusqu'à 320 kbps."},
                {"title": "Téléchargez le fichier", "text": "Le traitement se fait côté serveur, puis le fichier est enregistré sur votre appareil."},
            ],
            "extra_title": "Ce que vous obtenez",
            "extra": ["Un fichier sans filigrane ni logo ajouté", "Un nom de fichier propre, basé sur le titre de la vidéo",
                      "Un poids affiché avant même de lancer le téléchargement", "Un fichier lisible hors connexion",
                      "Aucune limite de durée liée à l'outil"],
            "faq": _faq("free", "safe", "device", "speed"),
            "related": _related(slug, [s for s in pages if pages[s].get("kind") == "intent"] + hub_related, hub_related),
            "priority": 0.75,
        }
    return pages


PAGES = build_pages()

# canonical nav / footer link sets
NAV = [
    ("/#fonctionnalites", "Fonctionnalités"),
    ("/#comment-ca-marche", "Comment ça marche"),
    ("/#formats", "Formats"),
    ("/#faq", "FAQ"),
    ("/telecharger-miniature-youtube", "Outils"),
]

FOOTER_COLUMNS = [
    ("Moteur de contenu", [
        ("/convertisseur-youtube", "Convertisseur YouTube"),
        ("/youtube-mp3", "Télécharger de l'audio"),
        ("/youtube-mp4", "Télécharger des vidéos"),
        ("/youtube-shorts", "Shorts"),
    ]),
    ("SEO & métadonnées", [
        ("/telecharger-miniature-youtube", "Miniatures"),
        ("/youtube-pour-etudiants", "Cas d'usage"),
        ("/youtube-1080p", "Qualité Full HD"),
        ("/youtube-2160p", "Qualité 4K"),
    ]),
    ("Téléchargements", [
        ("/youtube-mp3", "Télécharger audio MP3"),
        ("/youtube-mp4", "Télécharger vidéo MP4"),
        ("/youtube-1080p", "Télécharger en 1080p"),
        ("/youtube-720p", "Télécharger en 720p"),
    ]),
    ("Plateformes", [
        ("/telecharger-youtube-sur-iphone", "iPhone"),
        ("/telecharger-youtube-sur-android", "Android"),
        ("/telecharger-youtube-sur-windows", "Windows"),
        ("/telecharger-youtube-sur-mac", "Mac"),
    ]),
]


def all_slugs() -> list[str]:
    return sorted(PAGES)


def sitemap_entries(base: str) -> list[dict]:
    out = [{"loc": base + "/", "priority": "1.0"}]
    for slug, p in PAGES.items():
        out.append({"loc": f"{base}/{slug}", "priority": f"{p.get('priority', 0.6)}"})
    out.append({"loc": base + "/mentions-legales", "priority": "0.2"})
    out.append({"loc": base + "/confidentialite", "priority": "0.2"})
    out.append({"loc": base + "/conditions", "priority": "0.2"})
    return out
