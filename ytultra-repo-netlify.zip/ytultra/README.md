# ytultra — YouTube Downloader + pSEO + Admin

نسخة جديدة بالتصميم ديال الصورة المرفقة: هيرو غامق، لون أحمر `#e11d2e`، خلفية بيضاء، أقسام منظمة (Comment ça marche / Fonctionnalités / Pour qui / Cas d'utilisation / Formats / FAQ / Outils associés / Bloc SEO / Footer).

> ⚠️ هاد النسخة بدّلت التطبيق القديم (`ytdl-app`) حيت بغيتي *نفس التصميم* ديال الصورة.

---

## 1) واش التحميل خدام؟

نعم، **خدام فعلياً** ومختبَر:
- `yt-dlp` كيجيب الفيديو، `ffmpeg` كيدمج الصوت مع الصورة، والملف كيتنزّل MP4.
- الجودات: 144p → **2160p 4K** (حسب الفيديو) + صوت **MP3** 128/192/320 kbps.
- شريط تقدّم حقيقي (نسبة + سرعة + وقت متبقّي) + مرحلة الدمج + حفظ تلقائي.

## 2) pSEO — شنو تزاد

**45 صفحة SEO مبرمجة** (programmatic) كل واحدة عندها:
`title` + `meta description` + `canonical` + `H1` + محتوى فريد + FAQ + `schema.org (FAQPage + BreadcrumbList)` + صفحات مرتبطة داخلياً + `priority` فـ sitemap.

| المجموعة | العدد | أمثلة |
|---|---|---|
| Formats | 12 | `/youtube-mp3` · `/youtube-mp4` · `/youtube-en-webm` · `/youtube-en-m4a` · `/youtube-en-wav` · `/youtube-en-flac` · `/youtube-en-aac` · `/youtube-en-ogg` · `/youtube-en-avi` · `/youtube-en-mov` · `/youtube-en-mkv` · `/youtube-en-3gp` |
| Qualités | 8 | `/youtube-1080p` · `/youtube-2160p` · `/youtube-720p` … |
| Appareils | 7 | `/telecharger-youtube-sur-iphone` · `…android` · `…windows` · `…mac` · `…linux` · `…ipad` · `…smart-tv` |
| Audiences | 6 | `/youtube-pour-etudiants` · `…createurs` · `…chercheurs` · `…professeurs` · `…monteurs` · `…podcasteurs` |
| Types de contenu | 4 | `/youtube-shorts` · `/youtube-music` · `/youtube-live` · `/telecharger-chaine-youtube` |
| Intentions | 8 | `…-sans-logiciel` · `…-sans-inscription` · `…-en-ligne` · `…-gratuit` · `…-rapide` · `/convertisseur-youtube` · `/telecharger-miniature-youtube` |

زيادة على:
- `/sitemap.xml` أوتوماتيكي (كيتحيّن مع كل صفحة جديدة أو معطّلة).
- `/robots.txt` قابل للتعديل من الـadmin.
- صفحات قانونية: `/mentions-legales`, `/confidentialite`, `/conditions`.
- صفحة 404 مخصصة.

## 3) Panneau Admin — `/admin`

| الصفحة | شنو كدير |
|---|---|
| `/admin/login` | دخول بكلمة سر (افتراضياً `admin123` — بدّلها من الإعدادات) |
| `/admin` | داشبورد: صفحات مزارة، تحميلات، pages SEO، حجم البيانات، graph 14 يوم، آخر التحميلات، حالة yt-dlp/ffmpeg |
| `/admin/pages` | لائحة 45 صفحة + بحث + **toggle indexée** (كتخرج من sitemap فوراً) + تعديل/عرض |
| `/admin/pages/<slug>/edit` | تعديل `title`, `meta description`, `H1`, `intro` (override محفوظ فـ SQLite) + Réinitialiser |
| `/admin/pages/new` | إنشاء صفحة pSEO جديدة (slug, title, description, H1, intro, body, FAQ) — كتدخل أوتوماتيك فـ sitemap |
| `/admin/downloads` | سجل التحميلات (statut, qualité, حجم) + حذف |
| `/admin/settings` | اسم الموقع، الشعار، الجودة الافتراضية، تفعيل الإحصائيات، robots.txt، تغيير كلمة السر |

## 4) التشغيل

```bash
cd ytultra
./run.sh                     # التثبيت + ffmpeg + السيرفر
# أو
pip install -r requirements.txt && python3 app.py
```

ثم:
- الموقع: `http://localhost:8000`
- الإدارة: `http://localhost:8000/admin` (كلمة السر: `admin123`)

للإنتاج:
```bash
waitress-serve --listen=0.0.0.0:8000 app:app
```

## 5) بنية المشروع

```
ytultra/
├─ app.py           # Flask : routes publiques, API, admin
├─ pseo.py          # محرّك pSEO (registre + copywriting + FAQ + related + sitemap)
├─ downloader.py    # yt-dlp/ffmpeg + jobs + thumbnails
├─ db.py            # SQLite : settings, pages overrides, stats, jobs
├─ templates/       # landing, page pSEO, legal, 404 + admin/*
├─ static/          # style.css (public), admin.css, site.js
├─ bin/ffmpeg       # ffmpeg محلي
├─ data.db          # SQLite (كيتخلق أوتوماتيك)
└─ run.sh
```

## 6) API

| Méthode | Route | Description |
|---|---|---|
| `POST` | `/api/info` | عنوان + جودات + حجم تقريبي |
| `POST` | `/api/download` | بدء مهمة (`kind`: video/audio، `height`/`abr`، `slug`) |
| `GET` | `/api/job/<id>` | تقدّم (percent, speed, eta, phase) |
| `GET` | `/api/file/<id>` | تنزيل الملف |
| `GET` | `/api/thumb/<videoId>?q=maxresdefault` | صورة مصغّرة |

## 7) ملاحظات

- **غيّر كلمة السر** من `/admin/settings` قبل أي نشر.
- التحميل للأغراض الشخصية فقط — احترم حقوق النشر.
- الفيديوهات الخاصة / المحدودة بالعمر ما كتتحملش (يوتيوب كيمنعها).
- الملفات المؤقتة كتمسح أوتوماتيكياً بعد ساعة (`/tmp/ytultra-jobs`).
- حدّث `yt-dlp` بزاف مرات: `pip install -U yt-dlp`.
- باش تضيف كوكيز للفيديوهات المحظورة: زيد `cookiefile` فـ `ydl_base_opts()` فـ `downloader.py`.
