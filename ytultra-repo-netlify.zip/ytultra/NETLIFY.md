# 🟢 النشر على Netlify

## ⚠️ أولاً: حدود مهمة تعرفها

Netlify **ما كيشغّلش Python** — غير static + Node/Python Functions محدودة (بلا ffmpeg، بلا `yt-dlp`، بلا تخزين مؤقت للملفات).

| مكوّن | Netlify | علاش |
|---|---|---|
| الموقع + 49 صفحة SEO | ✅ **خدام** | static HTML |
| التصميم / CSS / JS | ✅ | assets |
| sitemap.xml + robots.txt | ✅ | توليد أوتوماتيك |
| **التحميل الفعلي (yt-dlp + ffmpeg)** | ❌ | محتاج سيرفر Python حقيقي |

**الحل** = **Frontend على Netlify** + **Backend صغير على Render/Railway/Cloud Run** (مجاني).
الواجهة كتحوّل الطلبات للـbackend عبر `config.js`.

```
الزائر → ytultra.netlify.app  (HTML/CSS/JS مجاني + HTTPS + CDN عالمي)
                     ↓ fetch() + CORS
          ytultra-api.onrender.com  (Python + yt-dlp + ffmpeg)
                     ↓
                الملف يرجع للزائر
```

---

## 🚀 النشر — 3 خطوات

### 1️⃣ انشر الـBackend أولاً (مرة واحدة، ~8 دقايق)

**Render (مجاني):**
```bash
# ارفع المشروع على GitHub
cd ytultra
git init && git add . && git commit -m "ytultra"
git remote add origin https://github.com/USERNAME/ytultra.git
git push -u origin main
```
Render → **New → Blueprint** → اختار الريبو (كيشد `render.yaml`) → دخّل:
- `ADMIN_PASSWORD` = كلمة سر قوية
- `PUBLIC_BASE_URL` = `https://ytultra-api.onrender.com`

ملاحظة: `render.yaml` فيه `disk` على `/data` (باقي محتاج خطة مدفوعة)، فمجاناً بدّلو لـ:
```yaml
          YTULTRA_DB: /tmp/data.db
          JOBS_DIR: /tmp/ytultra-jobs
```

**أو Railway / Cloud Run:** شوف `DEPLOY.md` و `GOOGLE_CLOUD.md`.

تأكد أن الـAPI خدام:
```bash
curl https://ytultra-api.onrender.com/healthz
# {"ffmpeg":true,"ok":true,"pages":45}
```

### 2️⃣ انشر الـFrontend على Netlify

**الطريقة A — سحب الريبو (موصى بها):**
1. netlify.com → **Add new site → Import an existing project**
2. اختار GitHub → نفس الريبو
3. Netlify كيقرا `netlify.toml` أوتوماتيك:
   - **Build command**: `pip install -r requirements-build.txt && python build_static.py`
   - **Publish directory**: `dist`
4. **Site settings → Environment variables** زيد:
   ```
   SITE_URL = https://ytultra.netlify.app     (أو الدومين ديالك)
   API_BASE = https://ytultra-api.onrender.com
   ```
5. **Deploy site**

**الطريقة B — Drag & Drop (سريع بلا Git):**
1. حمّل `ytultra-netlify-static.zip` (عندك فوق)
2. فـ Netlify: **Sites → Drag and drop** → حط الـzip
3. عدّل `config.js` إلا بدّلت الـbackend (من **Deploys → Deploy file browser**)

### 3️⃣ اربط الدومين (اختياري)
Netlify → **Domain management → Add custom domain** → بدّل الـDNS عند الـregistrar:
```
CNAME  www   →  your-site.netlify.app
A      @     →  75.2.60.5
```
SSL كيتفعّل أوتوماتيك.

بعدها بدّل `SITE_URL` فـ Netlify env vars باش `/sitemap.xml` و الـcanonical يتبعو الدومين الجديد.

---

## 📁 شنو كيتولّد فـ `dist/`

```
dist/
├── index.html                    ← الهوم
├── youtube-mp3/index.html        ← 45 صفحة pSEO (URLs نظيفة)
├── youtube-1080p/index.html
├── telecharger-youtube-sur-iphone/index.html
├── ...
├── mentions-legales/index.html
├── confidentialite/index.html
├── conditions/index.html
├── 404.html
├── config.js                     ← API_BASE (كيتولّد من env)
├── sitemap.xml                   ← 49 URL
├── robots.txt
├── _redirects                    ← Netlify: 404
└── static/                       ← style.css, admin.css, site.js
```

**النتيجة:** 49 صفحة HTML خفيفة (1.4 MB) + CDN + HTTPS مجاني.

---

## ⚠️ حوايج خاصك تعرفها

### 1) لوحة التحكم (`/admin`) ما كتخدمش على Netlify
الـadmin محتاج Python + SQLite. كتلقاها على **الـbackend** فقط:
```
https://ytultra-api.onrender.com/admin
```
(هاد الرابط ما تشاركوش علنياً).

### 2) CORS
الـbackend كيرجع `Access-Control-Allow-Origin: *` — خدام مزيان. إلا بغيتي تحكمو:
فـ `app.py` بدّل `"*"` بـ`["https://ytultra.netlify.app"]`.

### 3) التحميل كيمرّ عبر السيرفر
الملف كيتنزّل من الـbackend → نت كيتحمّل الـbandwidth ديال Render/Railway، ماشي Netlify.
هادشي مزيان للـfree tier ديال Netlify (100GB/شهر) ولكن راقب الـegress ديال الـbackend.

### 4) Cold start
Render المجاني كيرقد بعد 15 دقيقة → أول تحميل كياخد ~30 ثانية. الحل:
- خطة مدفوعة (7$/شهر)، أو
- ping كل 10 دقايق من **UptimeRobot** (مجاني)، أو
- Cloud Run مع `--min-instances=1`.

### 5) صورة الفيديو المصغّرة
كتجي من الـbackend (`/api/thumb/...`) — تأكد `config.js` فيه `API_BASE` صحيح.

### 6) بعد كل تحديث للكود
Netlify كيبني أوتوماتيك ملي كتدير `git push` — 49 صفحة كيتولّدو من جديد.
إلا بدّلت موضوع فـ pSEO، غير دير push و صافي.

---

## ✅ Checklist

- [ ] الـbackend خدام: `curl .../healthz`
- [ ] `API_BASE` صحيح فـ Netlify env vars
- [ ] `SITE_URL` = الدومين النهائي (للـcanonical)
- [ ] جرّبت تحميل فيديو حقيقي من الموقع المنشور
- [ ] الصورة المصغّرة كتبان
- [ ] `/youtube-mp3` كتحل بـURL نظيف بلا `.html`
- [ ] `/sitemap.xml` كيوري الدومين الصحيح
- [ ] زدت الموقع فـ Google Search Console
- [ ] كلمة سر الـadmin بدّلتها فـ `/admin/settings`
