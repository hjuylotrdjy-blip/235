#!/usr/bin/env bash
# ytultra — démarrage (installe ce qui manque, puis lance le serveur)
set -e
cd "$(dirname "$0")"

if ! python3 -c "import flask, yt_dlp, requests" >/dev/null 2>&1; then
  echo "→ Installation des dépendances…"
  pip install -q -r requirements.txt
fi

# ffmpeg local (fusion vidéo + audio, conversion MP3)
if [ ! -x "./bin/ffmpeg" ]; then
  mkdir -p bin
  python3 - <<'PY' || true
import imageio_ffmpeg, shutil
shutil.copy(imageio_ffmpeg.get_ffmpeg_exe(), "bin/ffmpeg")
PY
  chmod +x bin/ffmpeg 2>/dev/null || true
fi

export PORT="${PORT:-8000}"
echo "▶ ytultra sur http://0.0.0.0:$PORT  (admin : /admin — mot de passe admin123)"
exec python3 app.py
