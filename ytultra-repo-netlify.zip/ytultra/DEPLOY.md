# 🚀 دليل رفع ytultra على الاستضافة

هاد الدليل كيغطي 3 طرق، من الأحسن للأسهل. **الطريقة A (VPS) هي اللي كننصح بيها** لهاد النوع من التطبيقات، حيت yt-dlp كيحتاج ffmpeg + IP ماشي محظور من يوتيوب + معالجة طويلة.

| الطريقة | صعوبة | التكلفة | مناسبة؟ |
|---|---|---|---|
| **A. VPS + Docker + Caddy** | متوسط | ~5–10€/شهر | ✅ الأحسن |
| **B. Render / Railway** | ساهل | مجاني محدود / ~7$/شهر | ⚠️ كيخدم، ولكن IP ديال الداتاسنتر كيتحظر بزاف |
| **C. cPanel / Shared (Hostinger، Namecheap…)** | متوسط | ~3€/شهر | ⚠️ ممكن ولكن يحتاج ffmpeg يدوي |

> ⚠️ **مستحيل** يتخدم على استضافة static فقط (Netlify، Vercel static، GitHub Pages) — حيت التطبيق محتاج Python + ffmpeg + كتابة ملفات.

---

## أول حاجة: شنو خاصك

1. **دومين** (اختياري ولكن مهم للـ SEO).
2. الاستضافة (VPS / PaaS / cPanel).
3. تعرف الـIP ديال السيرفر باش تربط الـDNS.

### متغيرات البيئة (مهمة)

| المتغير | الوصف | مثال |
|---|---|---|
| `SECRET_KEY` | مفتاح توقيع الجلسات | `openssl rand -hex 32` |
| `ADMIN_PASSWORD` | كلمة سر `/admin` (كتتطبق فكل restart) | `MyStr0ngPass!` |
| `PUBLIC_BASE_URL` | الرابط العمومي بالـhttps (للـcanonical و sitemap) | `https://ytultra.com` |
| `YTULTRA_DB` | مسار قاعدة SQLite | `/data/data.db` |
| `JOBS_DIR` | مجلد الملفات المؤقتة | `/data/jobs` |
| `TRUST_PROXY` | يخلي التطبيق يقرا `X-Forwarded-*` | `1` |

---

# ✅ الطريقة A — VPS + Docker + Caddy (موصى بها)

**المطلوب:** Ubuntu 22.04/24.04، 1 CPU، **1GB RAM** (2GB أحسن)، 10GB disk.

### 1) دخول للسيرفر
```bash
ssh root@IP_DI_SERVER
```

### 2) تثبيت Docker
```bash
apt update && apt upgrade -y
curl -fsSL https://get.docker.com | sh
apt install -y docker-compose-plugin git
```

### 3) رفع المشروع
```bash
mkdir -p /opt && cd /opt
# إما git clone من الريبو ديالك:
git clone https://github.com/USERNAME/ytultra.git
cd ytultra
# أو ارفع مجلد ytultra بـ scp:
# scp -r ./ytultra root@IP:/opt/
```

### 4) إعداد المتغيرات
```bash
cp .env.example .env
nano .env
```
دخّل:
```env
SECRET_KEY=<output ديال openssl rand -hex 32>
ADMIN_PASSWORD=<كلمة السر اللي بغيتي>
DOMAIN=ytultra.com
```

### 5) ربط الدومين
فـ DNS ديال الدومين زيد:
```
A     @      IP_DI_SERVER
A     www    IP_DI_SERVER
```
(استنى 5–30 دقيقة حتى ينتشر)

### 6) تشغيل
```bash
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml logs -f ytultra
```

Caddy كيجيب **شهادة SSL أوتوماتيكياً**. حل `https://ytultra.com` 🎉

### 7) أوامر يومية
```bash
docker compose -f docker-compose.prod.yml ps          # الحالة
docker compose -f docker-compose.prod.yml logs -f     # اللوغ
docker compose -f docker-compose.prod.yml restart     # restart
docker compose -f docker-compose.prod.yml down        # وقف
```

### 8) تحديث yt-dlp (مهم بزاف — يوتيوب كيتبدل)
```bash
docker compose -f docker-compose.prod.yml build --no-cache ytultra
docker compose -f docker-compose.prod.yml up -d
```
> برمجها كل أسبوع بـ cron:
> `0 4 * * 1 cd /opt/ytultra && docker compose -f docker-compose.prod.yml build --no-cache && docker compose -f docker-compose.prod.yml up -d`

### 9) باكاب (نسخة احتياطية)
```bash
docker run --rm -v ytultra_ytultra-data:/data -v /root:/backup alpine \
  tar czf /backup/ytultra-$(date +%F).tar.gz /data
```
> `data.db` فيه الإعدادات، صفحات pSEO، الإحصائيات، و hash ديال كلمة السر.

---

# ✅ الطريقة B — Render / Railway (بلا سيرفر)

المشروع فيه `render.yaml` و `Procfile` و `Dockerfile` جاهزين.

### Render
1. ارفع المشروع على GitHub.
2. Render → **New → Blueprint** → اختار الريبو (كيتعرف على `render.yaml`).
3. فـ Dashboard دخّل:
   - `ADMIN_PASSWORD`
   - `PUBLIC_BASE_URL` = `https://ytultra.onrender.com` (أو الدومين ديالك)
4. Deploy. أول build كياخد 3–5 دقايق.

### Railway
1. New Project → Deploy from GitHub.
2. Railway كيشد `Dockerfile` أوتوماتيكياً.
3. Variables: نفس اللي فوق + `PORT` كيتعطى أوتوماتيك.
4. Settings → Networking → Generate Domain.

⚠️ ملاحظات:
- **ما تخدمش أكثر من instance وحدة** (التحميلات فالميموري) — خلي `1 replica`.
- فـ Railway/Render الفايلات مؤقتة إلا زدتي **Volume** على `/data`.
- IP ديال الداتاسنتر كيتحظر من يوتيوب أكثر من VPS عادي → شوف قسم "مشاكل يوتيوب" تحت.

---

# ✅ الطريقة C — cPanel / استضافة مشتركة

خاصك استضافة كتدعم **Python App** (Hostinger Business، Namecheap، A2…).

### 1) إنشاء التطبيق
cPanel → **Setup Python App** → Create Application:
- **Python version**: 3.11+
- **Application root**: `ytultra`
- **Application URL**: الدومين ديالك
- **Application startup file**: `passenger_wsgi.py`
- **Entry point**: `application`

### 2) إنشاء `passenger_wsgi.py`
فـ مجلد التطبيق (`~/ytultra/`):
```python
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
os.environ.setdefault("SECRET_KEY", "بدلها-بمفتاح-عشوائي")
os.environ.setdefault("ADMIN_PASSWORD", "كلمة-السر-ديالك")
os.environ.setdefault("PUBLIC_BASE_URL", "https://your-domain.com")
os.environ.setdefault("JOBS_DIR", os.path.join(os.path.dirname(__file__), "jobs"))
os.environ.setdefault("YTULTRA_DB", os.path.join(os.path.dirname(__file__), "data.db"))
from app import app as application
```

### 3) رفع الملفات
ارفع `ytultra-deploy.zip` (فيه المشروع بلا `data.db`) بـ **File Manager**، ثم Extract.

### 4) تثبيت المكتبات
فـ Terminal ديال cPanel (أو من واجهة Setup Python App):
```bash
source /home/USER/virtualenv/ytultra/3.11/bin/activate
cd ~/ytultra
pip install -r requirements.txt
```

### 5) ffmpeg
- إلا كان عندك SSH وصلاحيات: حمّل static build وحطو فـ `bin/ffmpeg` + `chmod +x bin/ffmpeg`.
- إلا لا: `pip install imageio-ffmpeg` كافي (التطبيق كيلقاه أوتوماتيكياً).
```bash
python -c "import imageio_ffmpeg, shutil; shutil.copy(imageio_ffmpeg.get_ffmpeg_exe(), 'bin/ffmpeg')"
chmod +x bin/ffmpeg
```

### 6) إعادة التشغيل
Setup Python App → **Restart** → حل الموقع.

### 7) SSL
cPanel → **SSL/TLS Status** → Run AutoSSL.

---

## 🧪 بعد الرفع — Checklist

```bash
curl https://your-domain.com/healthz          # {"ok":true,...}
curl https://your-domain.com/robots.txt
curl https://your-domain.com/sitemap.xml | head
```

- [ ] `/admin` كتحل بكلمة السر الجديدة
- [ ] بدّلت كلمة السر من **Paramètres → Sécurité**
- [ ] `PUBLIC_BASE_URL` صحيح (شوف: `<link rel="canonical">` فـ view-source)
- [ ] HTTPS خدام و `SESSION_COOKIE_SECURE` مفعّل
- [ ] جرّبت تحميل فيديو حقيقي (فيديو قصير)
- [ ] زدت `/sitemap.xml` فـ **Google Search Console** + Bing Webmaster
- [ ] Analytics/الخصوصية موافقة للقانون إلا كان عندك زوار من EU

---

## ⚠️ مشاكل معروفة وحلولها

### 1) "Sign in to confirm you're not a bot" / تحميل كيطيح
يوتيوب كيحظر IP ديال الداتاسنتر. الحلول:
- **cookies**: صدّر الكوكيز ديال حساب YouTube (بـ extension "Get cookies.txt") وحطها فـ `/data/cookies.txt`، ثم فـ `downloader.py` فـ `ydl_base_opts()` زيد:
  ```python
  "cookiefile": "/data/cookies.txt",
  ```
- **proxy سكني** (Bright Data، IPRoyal…) فـ `yt-dlp`:
  ```python
  "proxy": "http://user:pass@host:port",
  ```
- VPS فـ بلد فيه يوتيوب ما كيبلوكيش بزاف + تحديث yt-dlp.

### 2) التحميل كيبقى "queued" أو الصفحة ما كتحدّثش
راك مشغّل أكثر من worker. **خلي `--workers 1`** (الـthreads كافي). إلا بغيتي scaling: خاصك Redis + RQ/Celery.

### 3) الديسك كيتعمر
الملفات كتمسح أوتوماتيكياً بعد ساعة. إلا بقا مشكل:
```bash
du -sh /var/lib/docker/volumes/*ytultra*/_data/jobs
find /data/jobs -mmin +60 -delete
```

### 4) 502 / Timeout على فيديوهات كبيرة
زد فـ Nginx/Caddy `read_timeout` (موجود 300s) و فـ gunicorn `--timeout 300`.

### 5) الجلسة ما كتدخلش (login loop)
إلا `PUBLIC_BASE_URL=https://...` وراك كتجرب على `http://` — الـcookie `Secure` ما كتمشيش. جرب بالـhttps أو بدّل `HTTPS=0` مؤقتاً.

---

## 📌 ملاحظات قانونية (مهمة)

- تحميل فيديوهات يوتيوب خارج التطبيق الرسمي كيخالف **شروط استخدام YouTube** فحالات كثيرة، وحقوق النشر.
- بزاف ديال شركات الاستضافة كتمنع "YouTube downloader" فـ ToS — **قراها قبل ما تخلّص**.
- ما تديرش إعلانات على محتوى محمي، وما تعاودش تنشر الفيديوهات.
- الحدود: التحميل للأغراض الشخصية فقط + صفحة disclaimer (موجودة: `/conditions`).

---

## 🗂️ ملفات النشر الموجودة فالمشروع

```
Dockerfile                 # صورة إنتاج (ffmpeg + gunicorn)
docker-compose.yml         # تشغيل بسيط على 8000
docker-compose.prod.yml    # + Caddy (HTTPS أوتوماتيك)
deploy/Caddyfile           # reverse proxy + SSL
deploy/nginx.conf          # بديل Nginx + certbot
render.yaml                # نشر أوتوماتيكي على Render
Procfile                   # Railway / Heroku
.env.example               # المتغيرات
ytultra-deploy.zip         # ZIP جاهز للرفع (cPanel / أي استضافة)
```
