/* ytultra — front-end logic (vanilla JS, no dependencies) */
(function () {
  "use strict";

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  /* Base de l'API : même origine par défaut, ou backend distant (Netlify, etc.) */
  const API = (typeof window !== "undefined" && window.YTULTRA_API ? window.YTULTRA_API : "").replace(/\/$/, "");
  const apiUrl = (path) => API + path;

  /* ─────────── mobile nav ─────────── */
  const navToggle = $("#navToggle");
  const mobileNav = $("#mobileNav");
  if (navToggle && mobileNav) {
    navToggle.addEventListener("click", () => {
      const open = !mobileNav.hidden;
      mobileNav.hidden = open;
      navToggle.setAttribute("aria-expanded", String(!open));
    });
  }

  /* ─────────── helpers ─────────── */
  function fmtSpeed(bps) {
    if (!bps) return "";
    const u = ["o/s", "Ko/s", "Mo/s", "Go/s"];
    let i = 0, v = bps;
    while (v >= 1024 && i < 3) { v /= 1024; i++; }
    return v.toFixed(v >= 100 ? 0 : 1) + " " + u[i];
  }
  function fmtEta(s) {
    if (!s || s <= 0) return "";
    s = Math.round(s);
    if (s >= 60) return `reste ${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
    return `reste ${s} s`;
  }
  function fmtViews(n) {
    if (!n) return "";
    try {
      return new Intl.NumberFormat("fr", { notation: "compact", maximumFractionDigits: 1 }).format(n) + " vues";
    } catch (e) { return n + " vues"; }
  }
  function fmtDate(s) {
    if (!s || s.length !== 8) return "";
    const m = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
    return `${+s.slice(6, 8)} ${m[+s.slice(4, 6) - 1] || ""} ${s.slice(0, 4)}`;
  }
  function videoId(input) {
    const raw = (input || "").trim();
    if (/^[A-Za-z0-9_-]{11}$/.test(raw)) return raw;
    const pats = [
      /(?:youtube\.com\/watch\?(?:.*&)?v=)([A-Za-z0-9_-]{11})/,
      /youtu\.be\/([A-Za-z0-9_-]{11})/,
      /youtube\.com\/shorts\/([A-Za-z0-9_-]{11})/,
      /youtube\.com\/embed\/([A-Za-z0-9_-]{11})/,
      /music\.youtube\.com\/watch\?(?:.*&)?v=([A-Za-z0-9_-]{11})/,
    ];
    for (const p of pats) { const m = raw.match(p); if (m) return m[1]; }
    return null;
  }
  async function api(path, opts) {
    let res;
    try {
      res = await fetch(path, opts);
    } catch (e) {
      const err = new Error("Service de téléchargement injoignable pour le moment. Réessayez plus tard.");
      err.network = true;
      throw err;
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* ignore */ }
    if (!res.ok) throw new Error((data && data.error) || "Erreur de communication avec le serveur.");
    return data;
  }

  /* ══════════════════ MAIN DOWNLOADER WIDGET ══════════════════ */
  function initDownloader() {
  const root = $("#dw");
  if (!root) return;

  const el = {
    form: $("#dwForm"), url: $("#dwUrl"), paste: $("#dwPaste"), submit: $("#dwSubmit"),
    msg: $("#dwMsg"), result: $("#dwResult"), thumb: $("#dwThumb"), dur: $("#dwDur"),
    title: $("#dwTitle"), channel: $("#dwChannel"), views: $("#dwViews"), date: $("#dwDate"), live: $("#dwLive"),
    gridV: $("#dwGridVideo"), gridA: $("#dwGridAudio"), paneV: $("#dwPaneVideo"), paneA: $("#dwPaneAudio"),
    summary: $("#dwSummary"), download: $("#dwDownload"), progress: $("#dwProgress"),
    fill: $("#dwFill"), pct: $("#dwPct"), pstat: $("#dwPstat"), done: $("#dwDone"),
    file: $("#dwFile"), save: $("#dwSave"),
  };

  const state = { info: null, kind: "video", height: null, abr: 192, jobId: null, poll: null, busy: false };
  const AUDIO = [
    { abr: 320, label: "Qualité maximale" },
    { abr: 192, label: "Recommandé" },
    { abr: 128, label: "Léger" },
  ];

  function setMsg(text, ok) {
    el.msg.textContent = text || "";
    el.msg.classList.toggle("ok", !!ok);
  }
  function clearJob() {
    if (state.poll) { clearInterval(state.poll); state.poll = null; }
    state.jobId = null;
    el.progress.hidden = true;
    el.done.hidden = true;
    el.fill.style.width = "0%";
    el.pct.textContent = "0 %";
    el.pstat.textContent = "Préparation…";
    el.download.disabled = false;
  }

  async function analyze(raw) {
    const url = (raw || "").trim();
    if (!url) { setMsg("Collez d'abord un lien YouTube."); el.url.focus(); return; }
    if (state.busy) return;
    state.busy = true;
    clearJob();
    el.submit.disabled = true;
    const label = $(".dw-submit-label", el.submit);
    const oldLabel = label ? label.textContent : null;
    if (label) label.textContent = "Analyse…";
    setMsg("");

    try {
      const info = await api(apiUrl("/api/info"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      render(info);
    } catch (err) {
      setMsg(err.message);
      el.result.hidden = true;
    } finally {
      state.busy = false;
      el.submit.disabled = false;
      if (label) label.textContent = oldLabel;
    }
  }

  function render(info) {
    state.info = info;
    const hs = info.qualities.map(q => q.height);
    state.height = hs.includes(1080) ? 1080 : (hs.filter(h => h <= 1080).sort((a, b) => b - a)[0] || hs[0] || null);
    state.abr = 192;

    // la miniature peut être servie par le backend (chemin relatif) ou par YouTube (URL absolue)
    const thumb = info.thumbnail || "";
    el.thumb.src = /^(https?:)?\/\//.test(thumb) ? thumb : apiUrl(thumb);
    el.thumb.alt = info.title;
    el.thumb.style.display = "";
    el.dur.textContent = info.is_live ? "LIVE" : info.duration_str;
    el.title.textContent = info.title;
    el.channel.textContent = info.uploader;
    el.views.textContent = fmtViews(info.views);
    el.date.textContent = fmtDate(info.upload_date);
    el.live.hidden = !info.is_live;

    el.gridV.innerHTML = "";
    if (!info.qualities.length) {
      el.gridV.innerHTML = '<p class="dw-hint" style="grid-column:1/-1">Aucune qualité vidéo disponible — essayez l\'onglet Audio.</p>';
    }
    info.qualities.forEach(q => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "dw-q" + (q.height === state.height ? " is-sel" : "");
      b.dataset.h = q.height;
      b.innerHTML = `<b>${q.height}p</b><small>${q.label}${q.fps ? " · " + q.fps + " fps" : ""}</small>` +
                    `<span class="sq">${q.size ? "≈ " + q.size : "MP4"}</span>`;
      b.addEventListener("click", () => {
        state.height = q.height;
        $$(".dw-q", el.gridV).forEach(x => x.classList.toggle("is-sel", +x.dataset.h === q.height));
        updateSummary();
      });
      el.gridV.appendChild(b);
    });

    el.gridA.innerHTML = "";
    AUDIO.forEach(a => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "dw-q" + (a.abr === state.abr ? " is-sel" : "");
      b.dataset.abr = a.abr;
      b.innerHTML = `<b>${a.abr}<small> kbps</small></b><span class="sq">${a.label}</span>`;
      b.addEventListener("click", () => {
        state.abr = a.abr;
        $$(".dw-q", el.gridA).forEach(x => x.classList.toggle("is-sel", +x.dataset.abr === a.abr));
        updateSummary();
      });
      el.gridA.appendChild(b);
    });

    setKind("video");
    el.result.hidden = false;
    updateSummary();
    el.result.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function setKind(kind) {
    state.kind = kind;
    $$(".dw-tab", root).forEach(t => {
      const on = t.dataset.kind === kind;
      t.classList.toggle("is-active", on);
      t.setAttribute("aria-selected", on ? "true" : "false");
    });
    el.paneV.hidden = kind !== "video";
    el.paneA.hidden = kind !== "audio";
    updateSummary();
  }

  function updateSummary() {
    if (!state.info) return;
    if (state.kind === "video") {
      const q = state.info.qualities.find(x => x.height === state.height);
      el.summary.innerHTML = `Vidéo <b>${state.height ? state.height + "p" : "—"}</b> · MP4${q && q.size ? " · <b>" + q.size + "</b>" : ""}`;
    } else {
      el.summary.innerHTML = `Audio <b>MP3</b> · <b>${state.abr} kbps</b>`;
    }
  }

  async function startDownload() {
    if (!state.info || state.jobId) return;
    if (state.kind === "video" && !state.height) { setMsg("Aucune qualité vidéo disponible — essayez l'onglet Audio."); return; }
    el.download.disabled = true;
    el.done.hidden = true;
    el.progress.hidden = false;
    el.pct.textContent = "0 %";
    el.pstat.textContent = "Démarrage du téléchargement…";
    el.fill.style.width = "2%";

    try {
      const body = { url: state.info.webpage_url || el.url.value.trim(), kind: state.kind, slug: root.dataset.slug || "/" };
      if (state.kind === "video") body.height = state.height; else body.abr = state.abr;
      const r = await api(apiUrl("/api/download"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      state.jobId = r.job_id;
      poll();
    } catch (err) {
      el.progress.hidden = true;
      el.download.disabled = false;
      setMsg(err.message);
    }
  }

  function poll() {
    if (state.poll) clearInterval(state.poll);
    state.poll = setInterval(async () => {
      try {
        const j = await api(apiUrl("/api/job/" + state.jobId));
        if (j.status === "error") {
          clearInterval(state.poll); state.poll = null; state.jobId = null;
          el.progress.hidden = true;
          el.download.disabled = false;
          setMsg(j.error || "Le téléchargement a échoué.");
          return;
        }
        const pct = Math.min(100, Math.max(2, j.percent || 0));
        el.fill.style.width = pct + "%";
        el.pct.textContent = Math.round(pct) + " %";

        if (j.status === "ready") {
          clearInterval(state.poll); state.poll = null;
          el.fill.style.width = "100%";
          el.pct.textContent = "100 %";
          el.progress.hidden = true;
          el.done.hidden = false;
          el.file.textContent = j.filename || "Fichier prêt";
          el.download.disabled = false;
          triggerSave();
        } else {
          let phase = "Téléchargement…";
          if (j.phase === "merging") phase = "Fusion de l'audio et de la vidéo…";
          else if (j.phase === "converting") phase = "Conversion en MP3…";
          else if (j.phase === "queued") phase = "En file d'attente…";
          const bits = [phase];
          if (j.speed) bits.push(fmtSpeed(j.speed));
          const eta = fmtEta(j.eta);
          if (eta) bits.push(eta);
          el.pstat.textContent = bits.join(" · ");
        }
      } catch (e) { /* transient, keep polling */ }
    }, 700);
  }

  function triggerSave() {
    if (!state.jobId) return;
    const a = document.createElement("a");
    a.href = apiUrl("/api/file/" + state.jobId);
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  /* events */
  el.form.addEventListener("submit", e => { e.preventDefault(); analyze(el.url.value); });
  el.url.addEventListener("paste", () => setTimeout(() => {
    const v = el.url.value.trim();
    if (/^https?:\/\//i.test(v)) analyze(v);
  }, 60));
  el.paste.addEventListener("click", async () => {
    try {
      const txt = await navigator.clipboard.readText();
      if (!txt) { setMsg("Le presse-papiers est vide."); return; }
      el.url.value = txt.trim();
      analyze(txt);
    } catch (e) {
      el.url.focus();
      setMsg("Autorisez l'accès au presse-papiers ou faites Ctrl+V / Cmd+V.");
    }
  });
  $$(".dw-tab", root).forEach(t => t.addEventListener("click", () => setKind(t.dataset.kind)));
  el.download.addEventListener("click", startDownload);
  el.save.addEventListener("click", triggerSave);
  el.thumb.addEventListener("error", () => {
    el.thumb.style.display = "none";
    el.thumb.parentElement.style.background = "#1b1b21";
  });
  }

  /* ══════════════════ STATIC BUILD : vérifie le backend ══════════════════ */
  function initBackendCheck() {
    if (!window.YTULTRA_STATIC) return;
    fetch(apiUrl("/healthz"), { method: "GET" })
      .then(r => { if (!r.ok) throw 0; return r.json(); })
      .then(() => { document.documentElement.dataset.backend = "up"; })
      .catch(() => {
        document.documentElement.dataset.backend = "down";
        const bar = document.createElement("div");
        bar.className = "dw-offline-bar";
        bar.innerHTML =
          "<b>Mode vitrine</b> — le téléchargement a besoin d'un backend Python (yt-dlp + ffmpeg). " +
          "Renseignez <code>API_BASE</code> dans <code>config.js</code>. " +
          "Le site et les 49 pages SEO fonctionnent normalement.";
        const host = document.querySelector(".dw");
        if (host) host.parentElement.insertBefore(bar, host);
      });
  }

  /* ══════════════════ THUMBNAIL TOOL ══════════════════ */
  function initThumbTool() {
    const tw = $("#dwThumbTool");
    if (!tw) return;
    const form = $("#twForm"), input = $("#twUrl"), msg = $("#twMsg"), grid = $("#twGrid");
    const SIZES = [
      { q: "maxresdefault", label: "Max HD", dim: "1280 × 720" },
      { q: "sddefault", label: "SD", dim: "640 × 480" },
      { q: "hqdefault", label: "HQ", dim: "480 × 360" },
      { q: "mqdefault", label: "Moyenne", dim: "320 × 180" },
    ];
    form.addEventListener("submit", e => {
      e.preventDefault();
      const id = videoId(input.value);
      if (!id) { msg.textContent = "Lien YouTube invalide."; grid.hidden = true; return; }
      msg.textContent = "";
      grid.innerHTML = "";
      SIZES.forEach(s => {
        const url = apiUrl(`/api/thumb/${id}?q=${s.q}`);
        const card = document.createElement("div");
        card.className = "tw-card";
        card.innerHTML =
          `<img src="${url}" alt="Miniature ${s.label}" loading="lazy">
           <div class="tw-foot">
             <div><b>${s.label}</b><br><span>${s.dim} · JPG</span></div>
             <a href="${url}" download="miniature-${s.q}.jpg">Télécharger</a>
           </div>`;
        grid.appendChild(card);
      });
      grid.hidden = false;
      grid.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  initThumbTool();
  initDownloader();
  initBackendCheck();
})();
