/* ─────────────────────────────────────────────────────────────
   ytultra — configuration du site statique

   API_BASE : URL du backend Python (yt-dlp + ffmpeg).
   Laisser vide sur Netlify si vous n'avez pas encore de backend :
   le site + les 49 pages SEO fonctionnent, seul le téléchargement
   affichera un bandeau. Voir NETLIFY.md.
   ───────────────────────────────────────────────────────────── */
window.YTULTRA_API = '';
window.YTULTRA_SITE = 'https://ytultra-downloader.netlify.app';
window.YTULTRA_STATIC = true;
