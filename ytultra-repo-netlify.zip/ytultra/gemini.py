"""Génération de pages pSEO avec l'API Gemini (Google AI Studio).

Aucune dépendance supplémentaire : appel REST direct via `requests`.
Clé : variable d'environnement GEMINI_API_KEY  (https://aistudio.google.com/apikey)
"""
import json
import os
import re
import requests

API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")


def api_key() -> str:
    return os.environ.get("GEMINI_API_KEY", "").strip()


def enabled() -> bool:
    return bool(api_key())


SYSTEM = """Tu es un rédacteur SEO francophone spécialisé dans les outils de téléchargement YouTube.
Tu écris un contenu utile, concret, sans promesse trompeuse, et tu respectes le droit d'auteur.
Réponds UNIQUEMENT avec un objet JSON valide, sans markdown, avec ces clés :
title (≤ 60 caractères, contient le mot-clé principal),
description (≤ 155 caractères),
h1 (≤ 70 caractères),
intro (2 phrases de chapô),
body (4 à 6 paragraphes séparés par \\n\\n, 900 à 1400 caractères au total),
faq (tableau de 4 objets {"q": "...", "a": "..."}),
slug (kebab-case, ≤ 60 caractères, sans accent)."""


def _extract_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("Réponse du modèle non exploitable.")
    return json.loads(text[start:end + 1])


def generate_page(topic: str, keywords: str = "", lang: str = "fr") -> dict:
    key = api_key()
    if not key:
        raise RuntimeError("GEMINI_API_KEY n'est pas configurée.")

    prompt = (
        f"Sujet de la page : {topic}\n"
        f"Mots-clés à intégrer naturellement : {keywords or 'télécharger vidéo youtube, mp4, mp3'}\n"
        f"Langue : {lang}\n"
        "Public : visiteurs cherchant à télécharger une vidéo YouTube dans un format ou une qualité précis.\n"
        "Contraintes SEO : intention de recherche claire, pas de bourrage de mots-clés, "
        "mentionne que le service est gratuit, sans inscription, et rappelle l'usage personnel."
    )

    url = f"{API_BASE}/{MODEL}:generateContent?key={key}"
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.8, "maxOutputTokens": 2400,
                             "responseMimeType": "application/json"},
    }
    r = requests.post(url, json=payload, timeout=90)
    if r.status_code != 200:
        try:
            msg = r.json().get("error", {}).get("message", f"HTTP {r.status_code}")
        except Exception:
            msg = f"HTTP {r.status_code}"
        raise RuntimeError(f"Gemini : {msg}")

    data = r.json()
    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError):
        raise RuntimeError("Réponse vide du modèle (contenu bloqué ?).")

    out = _extract_json(text)
    out["slug"] = re.sub(r"[^a-z0-9-]+", "-", (out.get("slug") or topic).lower()).strip("-")[:60]
    out.setdefault("faq", [])
    return out


def faq_to_text(faq: list) -> str:
    return "\n".join(f"{item.get('q','')}|{item.get('a','')}" for item in faq if item.get("q"))
