#!/usr/bin/env python3
"""
ytultra — générateur de site statique (pour Netlify / Cloudflare Pages / GitHub Pages).

Il rend toutes les pages publiques (accueil + 45 pages pSEO + pages légales + 404)
en HTML pur, copie les assets, génère sitemap.xml / robots.txt et un config.js
qui pointe le widget vers le backend (yt-dlp a besoin d'un vrai serveur).

Usage :
    SITE_URL=https://ytultra.netlify.app API_BASE=https://api.exemple.com python build_static.py
"""
import os
import re
import shutil
from pathlib import Path

os.environ.setdefault("TRUST_PROXY", "0")

BASE_DIR = Path(__file__).resolve().parent
DIST = BASE_DIR / "dist"

SITE_URL = (os.environ.get("SITE_URL") or "https://ytultra.netlify.app").rstrip("/")
API_BASE = (os.environ.get("API_BASE") or "").rstrip("/")

os.environ["PUBLIC_BASE_URL"] = SITE_URL

import app as flask_app  # noqa: E402
import pseo  # noqa: E402

client = flask_app.app.test_client()


def clean(html: str) -> str:
    """Rend les assets relatifs, mais GARDE canonical / og:url absolus (SEO)."""
    html = html.replace(f"{SITE_URL}/static/", "/static/")
    # injecte config.js avant site.js
    html = html.replace(
        '<script src="/static/site.js"',
        '<script src="/config.js"></script>\n<script src="/static/site.js"',
    )
    return html


def write(path: str, content: str | bytes) -> None:
    target = DIST / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        target.write_bytes(content)
    else:
        target.write_text(content, encoding="utf-8")


def build() -> None:
    if DIST.exists():
        shutil.rmtree(DIST)
    DIST.mkdir(parents=True)

    # ── assets ────────────────────────────────────────────────
    shutil.copytree(BASE_DIR / "static", DIST / "static")

    # ── config.js : où se trouve le backend ──────────────────
    api = API_BASE or ""
    write("config.js", (
        "/* ─────────────────────────────────────────────────────────────\n"
        "   ytultra — configuration du site statique\n"
        "\n"
        "   API_BASE : URL du backend Python (yt-dlp + ffmpeg).\n"
        "   Laisser vide sur Netlify si vous n'avez pas encore de backend :\n"
        "   le site + les 49 pages SEO fonctionnent, seul le téléchargement\n"
        "   affichera un bandeau. Voir NETLIFY.md.\n"
        "   ───────────────────────────────────────────────────────────── */\n"
        f"window.YTULTRA_API = {api!r};\n"
        f"window.YTULTRA_SITE = {SITE_URL!r};\n"
        "window.YTULTRA_STATIC = true;\n"
    ))

    # ── pages ─────────────────────────────────────────────────
    routes: list[tuple[str, str]] = [("/", "index.html")]
    for slug in pseo.all_slugs():
        routes.append((f"/{slug}", f"{slug}/index.html"))
    for slug in ("mentions-legales", "confidentialite", "conditions"):
        routes.append((f"/{slug}", f"{slug}/index.html"))

    written, errors = 0, []
    for route, out in routes:
        r = client.get(route, base_url=SITE_URL)
        if r.status_code != 200:
            errors.append((route, r.status_code))
            continue
        write(out, clean(r.get_data(as_text=True)))
        written += 1

    # ── fichiers techniques ───────────────────────────────────
    for name in ("sitemap.xml", "robots.txt"):
        r = client.get(f"/{name}", base_url=SITE_URL)
        if r.status_code == 200:
            body = r.get_data(as_text=True).replace(SITE_URL, SITE_URL)
            write(name, body)

    # ── 404 ───────────────────────────────────────────────────
    r = client.get("/cette-page-nexiste-pas", base_url=SITE_URL)
    write("404.html", clean(r.get_data(as_text=True)))

    # ── (Netlify) redirection 404 + en-têtes ─────────────────
    write("_redirects", "/*    /404.html   404\n")

    print(f"✔ {written} pages générées dans {DIST}")
    print(f"  site : {SITE_URL}")
    print(f"  API  : {api or '(même origine — non configurée)'}")
    if errors:
        print(f"⚠ {len(errors)} pages en échec : {errors[:5]}")
    if not api:
        print("⚠ API_BASE vide : le téléchargement ne fonctionnera pas sur un hébergement statique.")


if __name__ == "__main__":
    build()
