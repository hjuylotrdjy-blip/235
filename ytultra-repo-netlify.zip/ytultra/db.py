"""SQLite persistence for ytultra: settings, page overrides, stats, download log."""
import hashlib
import os
import secrets
import sqlite3
import time
from pathlib import Path

DB_PATH = Path(os.environ.get("YTULTRA_DB", Path(__file__).resolve().parent / "data.db"))


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init_db() -> None:
    with _conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            CREATE TABLE IF NOT EXISTS pages (
                slug TEXT PRIMARY KEY,
                kind TEXT,
                title TEXT,
                description TEXT,
                h1 TEXT,
                intro TEXT,
                body TEXT,
                faq TEXT,
                enabled INTEGER DEFAULT 1,
                custom INTEGER DEFAULT 0,
                updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS page_daily (
                slug TEXT,
                day TEXT,
                views INTEGER DEFAULT 0,
                PRIMARY KEY (slug, day)
            );
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                url TEXT,
                title TEXT,
                slug TEXT,
                kind TEXT,
                quality TEXT,
                status TEXT,
                size INTEGER,
                filename TEXT,
                created REAL,
                finished REAL
            );
            """
        )
        defaults = {
            "site_name": "ytultra",
            "site_tagline": "Téléchargeur de vidéos YouTube",
            "default_quality": "1080",
            "analytics": "1",
            "robots": "User-agent: *\nAllow: /\n\nSitemap: {base}/sitemap.xml",
        }
        for k, v in defaults.items():
            c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?,?)", (k, v))

        # admin password (default admin123, changeable from the panel)
        row = c.execute("SELECT value FROM settings WHERE key='admin_hash'").fetchone()
        if not row:
            c.execute("INSERT INTO settings(key,value) VALUES('admin_hash',?)", (_hash("admin123"),))
        if not c.execute("SELECT value FROM settings WHERE key='secret_key'").fetchone():
            c.execute("INSERT INTO settings(key,value) VALUES('secret_key',?)", (secrets.token_hex(32),))


def _hash(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
    return f"{salt}${dk.hex()}"


def check_password(password: str) -> bool:
    row = get_setting("admin_hash")
    if not row or "$" not in row:
        return False
    salt, digest = row.split("$", 1)
    return secrets.compare_digest(_hash(password, salt).split("$", 1)[1], digest)


def set_password(password: str) -> None:
    set_setting("admin_hash", _hash(password))


def get_setting(key: str, default: str = "") -> str:
    with _conn() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with _conn() as c:
        c.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


# ----------------------------- pages -----------------------------
def get_override(slug: str) -> dict | None:
    with _conn() as c:
        row = c.execute("SELECT * FROM pages WHERE slug=?", (slug,)).fetchone()
        return dict(row) if row else None


def all_overrides() -> dict[str, dict]:
    with _conn() as c:
        return {r["slug"]: dict(r) for r in c.execute("SELECT * FROM pages")}


def custom_pages() -> list[dict]:
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM pages WHERE custom=1 ORDER BY updated_at DESC")]


def upsert_page(slug: str, **fields) -> None:
    fields["updated_at"] = time.time()
    keys = ["slug"] + list(fields.keys())
    vals = [slug] + list(fields.values())
    updates = ", ".join(f"{k}=excluded.{k}" for k in fields)
    with _conn() as c:
        c.execute(
            f"INSERT INTO pages({','.join(keys)}) VALUES({','.join('?' * len(keys))}) "
            f"ON CONFLICT(slug) DO UPDATE SET {updates}",
            vals,
        )


def delete_page(slug: str) -> None:
    with _conn() as c:
        c.execute("DELETE FROM pages WHERE slug=?", (slug,))


def enabled_map() -> dict[str, bool]:
    with _conn() as c:
        return {r["slug"]: bool(r["enabled"]) for r in c.execute("SELECT slug, enabled FROM pages")}


# ----------------------------- stats -----------------------------
def track_view(slug: str) -> None:
    day = time.strftime("%Y-%m-%d")
    with _conn() as c:
        c.execute(
            "INSERT INTO page_daily(slug, day, views) VALUES(?,?,1) "
            "ON CONFLICT(slug, day) DO UPDATE SET views = views + 1",
            (slug, day),
        )


def views_total() -> int:
    with _conn() as c:
        row = c.execute("SELECT COALESCE(SUM(views),0) v FROM page_daily").fetchone()
        return int(row["v"])


def views_today() -> int:
    with _conn() as c:
        row = c.execute(
            "SELECT COALESCE(SUM(views),0) v FROM page_daily WHERE day=?", (time.strftime("%Y-%m-%d"),)
        ).fetchone()
        return int(row["v"])


def top_pages(limit: int = 10) -> list[dict]:
    with _conn() as c:
        return [
            dict(r)
            for r in c.execute(
                "SELECT slug, SUM(views) views FROM page_daily GROUP BY slug ORDER BY views DESC LIMIT ?",
                (limit,),
            )
        ]


def views_series(days: int = 14) -> list[dict]:
    out = []
    with _conn() as c:
        for i in range(days - 1, -1, -1):
            day = time.strftime("%Y-%m-%d", time.localtime(time.time() - i * 86400))
            row = c.execute("SELECT COALESCE(SUM(views),0) v FROM page_daily WHERE day=?", (day,)).fetchone()
            out.append({"day": day, "views": int(row["v"])})
    return out


# ----------------------------- jobs -----------------------------
def log_job_start(jid: str, url: str, slug: str, kind: str, quality: str) -> None:
    with _conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO jobs(id,url,slug,kind,quality,status,created) VALUES(?,?,?,?,?,?,?)",
            (jid, url, slug, kind, quality, "running", time.time()),
        )


def log_job_finish(jid: str, status: str, size: int = 0, filename: str = "", title: str = "") -> None:
    with _conn() as c:
        c.execute(
            "UPDATE jobs SET status=?, size=?, filename=?, title=COALESCE(NULLIF(?,''),title), finished=? WHERE id=?",
            (status, size, filename, title, time.time(), jid),
        )


def jobs(limit: int = 50) -> list[dict]:
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM jobs ORDER BY created DESC LIMIT ?", (limit,))]


def downloads_count() -> dict:
    with _conn() as c:
        total = c.execute("SELECT COUNT(*) n FROM jobs WHERE status='ready'").fetchone()["n"]
        today = c.execute(
            "SELECT COUNT(*) n FROM jobs WHERE status='ready' AND date(created,'unixepoch','localtime')=date('now','localtime')"
        ).fetchone()["n"]
        bytes_ = c.execute("SELECT COALESCE(SUM(size),0) s FROM jobs").fetchone()["s"]
        return {"total": total, "today": today, "bytes": bytes_}


def downloads_series(days: int = 14) -> list[dict]:
    out = []
    with _conn() as c:
        for i in range(days - 1, -1, -1):
            day = time.strftime("%Y-%m-%d", time.localtime(time.time() - i * 86400))
            row = c.execute(
                "SELECT COUNT(*) n FROM jobs WHERE status='ready' "
                "AND date(created,'unixepoch','localtime')=?", (day,)
            ).fetchone()
            out.append({"day": day, "downloads": int(row["n"])})
    return out


def delete_job(jid: str) -> None:
    with _conn() as c:
        c.execute("DELETE FROM jobs WHERE id=?", (jid,))


def recent_activity(limit: int = 8) -> list[dict]:
    return jobs(limit)


def db_size() -> int:
    try:
        return DB_PATH.stat().st_size
    except OSError:
        return 0
