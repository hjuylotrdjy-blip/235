#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  ytultra → Google Cloud Run
#  Donne un domaine HTTPS gratuit : https://SERVICE-HASH-REGION.a.run.app
#  Usage :  ./deploy/cloudrun.sh [SERVICE_NAME] [REGION]
# ─────────────────────────────────────────────────────────────
set -euo pipefail

SERVICE="${1:-ytultra}"
REGION="${2:-europe-west1}"      # europe-west1 = faible latence pour le Maroc/Europe
PROJECT="$(gcloud config get-value project 2>/dev/null)"

if [ -z "$PROJECT" ] || [ "$PROJECT" = "(unset)" ]; then
  echo "❌ Aucun projet actif. Lance d'abord :  gcloud config set project TON_PROJECT_ID"
  exit 1
fi

echo "▶ Projet : $PROJECT"
echo "▶ Service : $SERVICE"
echo "▶ Région  : $REGION"

# 1) APIs nécessaires
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com

# 2) Secrets obligatoires (demandés une seule fois)
if [ -z "${ADMIN_PASSWORD:-}" ]; then
  read -rsp "Mot de passe admin (sera stocké sur Cloud Run) : " ADMIN_PASSWORD; echo
fi
SECRET_KEY="${SECRET_KEY:-$(openssl rand -hex 32)}"

# 3) Déploiement depuis le Dockerfile
gcloud run deploy "$SERVICE" \
  --source . \
  --region "$REGION" \
  --platform managed \
  --allow-unauthenticated \
  --port 8080 \
  --memory 2Gi \
  --cpu 2 \
  --timeout 3600 \
  --concurrency 20 \
  --min-instances 0 \
  --max-instances 1 \
  --session-affinity \
  --set-env-vars "ADMIN_PASSWORD=${ADMIN_PASSWORD},SECRET_KEY=${SECRET_KEY},TRUST_PROXY=1,YTULTRA_DB=/tmp/data.db,JOBS_DIR=/tmp/ytultra-jobs"

URL="$(gcloud run services describe "$SERVICE" --region "$REGION" --format='value(status.url)')"
echo "✅ Déployé : $URL"

# 4) URL canonique (SEO) : on la fixe après le premier déploiement
gcloud run services update "$SERVICE" --region "$REGION" \
  --update-env-vars "PUBLIC_BASE_URL=${URL}" >/dev/null
echo "✅ PUBLIC_BASE_URL = $URL"
echo
echo "   Site      : $URL"
echo "   Admin     : $URL/admin"
echo "   Sitemap   : $URL/sitemap.xml"
echo
echo "➡ Vérifie :  curl $URL/healthz"
