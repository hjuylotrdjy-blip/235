"""
ytultra — YouTube downloader + programmatic SEO + admin panel.
Flask + yt-dlp + SQLite.
"""
import json
import os
import re
from datetime import date
from pathlib import Path

from flask import (Flask, Response, abort, flash, jsonify, redirect, render_template,
                   request, send_file, session, url_for)

import db
import downloader as dl
import gemini
import pseo

BASE_DIR = Path(__file__).resolve().parent
db.init_db()

app = Flask(__name__)

# behind Nginx / Caddy / PaaS: trust forwarded headers (real host, https, IP)
if os.environ.get("TRUST_PROXY", "1") == "1":
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1)

app.secret_key = os.environ.get("SECRET_KEY") or db.get_setting("secret_key") or os.urandom(32).hex()
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

_PUBLIC_BASE = (os.environ.get("PUBLIC_BASE_URL") or "").rstrip("/")
_IS_HTTPS = _PUBLIC_BASE.startswith("https://") or os.environ.get("HTTPS", "0") == "1"
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=_IS_HTTPS,
    PERMANENT_SESSION_LIFETIME=60 * 60 * 12,
    PREFERRED_URL_SCHEME="https" if _IS_HTTPS else "http",
)

if os.environ.get("ADMIN_PASSWORD"):
    db.set_password(os.environ["ADMIN_PASSWORD"])
    print("ADMIN_PASSWORD applied from environment")


# ───────────────────────────── helpers ─────────────────────────────
def public_base() -> str:
    """Canonical public URL (env > proxy > request)."""
    if _PUBLIC_BASE:
        return _PUBLIC_BASE
    return request.url_root.rstrip("/")


def site_ctx():
    return {
        "site_name": db.get_setting("site_name", "ytultra"),
        "site_tagline": db.get_setting("site_tagline", "Téléchargeur de vidéos YouTube"),
        "year": date.today().year,
        "nav": pseo.NAV,
        "footer_columns": pseo.FOOTER_COLUMNS,
        "base_url": public_base(),
    }


def effective_page(slug: str) -> dict | None:
    """Registry page merged with admin overrides."""
    base = pseo.PAGES.get(slug)
    ov = db.get_override(slug)

    if base is None and (not ov or not ov.get("custom")):
        return None

    if ov and not ov.get("enabled", 1):
        return None

    if base is None:  # custom page from admin
        faq = []
        for line in (ov.get("faq") or "").splitlines():
            if "|" in line:
                q, a = line.split("|", 1)
                faq.append({"q": q.strip(), "a": a.strip()})
        return {
            "slug": slug,
            "kind": "custom",
            "kicker": "GUIDE",
            "h1": ov.get("h1") or ov.get("title") or slug,
            "title": ov.get("title") or slug,
            "description": ov.get("description") or "",
            "lead": ov.get("intro") or "",
            "intro": [p.strip() for p in (ov.get("body") or "").split("\n\n") if p.strip()],
            "benefits": [],
            "steps": [],
            "extra_title": "",
            "extra": [],
            "faq": faq,
            "related": ["youtube-mp3", "youtube-mp4", "youtube-1080p", "youtube-miniature"] if False else
                       ["youtube-mp3", "youtube-mp4", "youtube-1080p", "telecharger-miniature-youtube"],
            "priority": 0.5,
            "custom": True,
        }

    page = dict(base)
    if ov:
        for k in ("title", "description", "h1", "intro"):
            if ov.get(k):
                if k == "intro":
                    page["lead"] = ov[k]
                else:
                    page[k] = ov[k]
    return page


def bump_view(slug: str):
    if db.get_setting("analytics", "1") == "1":
        try:
            db.track_view(slug)
        except Exception:
            pass


@app.context_processor
def inject_globals():
    ctx = site_ctx()
    ctx["page_count"] = len(pseo.PAGES) + len(db.custom_pages())
    ctx.setdefault("active", "")
    return ctx


# ───────────────────────────── public pages ─────────────────────────────
@app.get("/")
def index():
    bump_view("/")
    return render_template("landing.html", page_title=None)


@app.get("/sitemap.xml")
def sitemap():
    base = public_base()
    entries = pseo.sitemap_entries(base)
    # pages personnalisées créées depuis l'admin
    for cp in db.custom_pages():
        if cp.get("enabled"):
            entries.append({"loc": f"{base}/{cp['slug']}", "priority": "0.5"})
    enabled = db.enabled_map()
    urls = []
    for e in entries:
        slug = e["loc"].replace(base, "").strip("/")
        if slug and enabled.get(slug) is False:
            continue
        urls.append(e)
    xml = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<urlset xmlns="http://www.sitemapseo.org/schemas/sitemap/0.9">'.replace("sitemapseo", "sitemaps")]
    for u in urls:
        xml.append(f"<url><loc>{u['loc']}</loc><lastmod>{date.today().isoformat()}</lastmod>"
                   f"<changefreq>weekly</changefreq><priority>{u['priority']}</priority></url>")
    xml.append("</urlset>")
    return Response("\n".join(xml), mimetype="application/xml")


@app.get("/robots.txt")
def robots():
    base = public_base()
    txt = db.get_setting("robots", "User-agent: *\nAllow: /") or ""
    txt = txt.replace("{base}", base)
    if "sitemap" not in txt.lower():
        txt += f"\n\nSitemap: {base}/sitemap.xml"
    return Response(txt, mimetype="text/plain")


LEGAL = {
    "mentions-legales": ("Mentions légales", [
        ("Éditeur du site", "ytultra est un outil technique de démonstration destiné au téléchargement de contenus pour un usage strictement personnel."),
        ("Hébergement", "Le service est hébergé sur une infrastructure cloud. Aucune donnée de compte n'est collectée."),
        ("Propriété intellectuelle", "Les vidéos téléchargées restent la propriété de leurs auteurs. L'utilisateur s'engage à respecter les droits d'auteur et les conditions d'utilisation de YouTube."),
        ("Contact", "Pour toute question relative au site, utilisez les canaux de contact de l'éditeur."),
    ]),
    "confidentialite": ("Politique de confidentialité", [
        ("Données collectées", "Aucune inscription n'est requise. Seules des statistiques anonymes de pages vues et de téléchargements sont enregistrées pour améliorer le service."),
        ("Cookies", "Un cookie de session est utilisé uniquement pour l'accès à l'espace d'administration."),
        ("Fichiers téléchargés", "Les fichiers sont stockés temporairement sur le serveur puis supprimés automatiquement après une heure."),
        ("Vos droits", "Vous pouvez demander la suppression des statistiques vous concernant à tout moment."),
    ]),
    "conditions": ("Conditions d'utilisation", [
        ("Usage autorisé", "Le service est destiné à un usage personnel et non commercial. Toute redistribution de contenus protégés est interdite."),
        ("Responsabilité", "L'utilisateur est seul responsable du respect des droits des créateurs et des conditions de YouTube."),
        ("Disponibilité", "Le service peut être interrompu à tout moment, notamment lors de changements techniques de la plateforme source."),
        ("Limites", "Les vidéos privées, réservées aux membres ou soumises à une restriction d'âge ne peuvent pas être téléchargées."),
    ]),
}


@app.get("/<slug>")
def public_page(slug: str):
    if slug in LEGAL:
        title, blocks = LEGAL[slug]
        bump_view(slug)
        return render_template("legal.html", title=title, blocks=blocks)

    page = effective_page(slug)
    if not page:
        return render_template("404.html"), 404
    bump_view(slug)

    enabled = db.enabled_map()
    related = [pseo.PAGES[s] for s in page.get("related", []) if s in pseo.PAGES and enabled.get(s, True)]
    faq_json = {"@context": "https://schema.org", "@type": "FAQPage",
                "mainEntity": [{"@type": "Question", "name": f["q"],
                                "acceptedAnswer": {"@type": "Answer", "text": f["a"]}} for f in page.get("faq", [])]}
    crumbs = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "Accueil", "item": public_base() + "/"},
        {"@type": "ListItem", "position": 2, "name": page["h1"], "item": request.base_url},
    ]}
    return render_template("page.html", page=page, related=related,
                           faq_json=json.dumps(faq_json, ensure_ascii=False),
                           crumbs_json=json.dumps(crumbs, ensure_ascii=False))


# ───────────────────────────── API ─────────────────────────────
@app.after_request
def headers(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    if request.path.startswith("/api/") or request.path in ("/", "/sitemap.xml", "/robots.txt"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


@app.post("/api/info")
def api_info():
    data = request.get_json(silent=True) or {}
    url = dl.normalize_url(data.get("url", ""))
    if not url:
        return jsonify({"error": "Lien invalide. Collez une URL YouTube (watch, youtu.be ou shorts)."}), 400
    try:
        info = dl.get_info(url)
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if "Private video" in msg:
            err = "Cette vidéo est privée."
        elif "age" in msg.lower() and "restrict" in msg.lower():
            err = "Vidéo réservée aux adultes : YouTube bloque le téléchargement."
        elif "unavailable" in msg.lower():
            err = "Vidéo indisponible ou bloquée dans cette région."
        else:
            err = "Impossible de récupérer les informations de la vidéo. Réessayez."
        return jsonify({"error": err}), 422
    if not info["qualities"] and not info["is_live"]:
        return jsonify({"error": "Aucune qualité téléchargeable trouvée pour cette vidéo."}), 422
    return jsonify(info)


@app.post("/api/download")
def api_download():
    data = request.get_json(silent=True) or {}
    url = dl.normalize_url(data.get("url", ""))
    kind = data.get("kind", "video")
    if not url:
        return jsonify({"error": "Lien invalide."}), 400
    if kind not in ("video", "audio"):
        return jsonify({"error": "Type de téléchargement inconnu."}), 400
    height = int(data.get("height") or 0)
    abr = int(data.get("abr") or 192)
    if kind == "audio" and abr not in (128, 192, 320):
        abr = 192
    slug = data.get("slug", "")
    jid = dl.start_job(url, kind, height, abr, slug=slug)
    return jsonify({"job_id": jid})


@app.get("/api/job/<jid>")
def api_job(jid):
    job = dl.get_job(jid)
    if not job:
        return jsonify({"error": "Tâche introuvable."}), 404
    return jsonify({
        "id": jid, "status": job["status"], "phase": job["phase"], "percent": job["percent"],
        "speed": job["speed"], "eta": job["eta"], "filename": job["filename"],
        "size": job.get("size_str"), "error": job["error"],
    })


@app.get("/api/file/<jid>")
def api_file(jid):
    path = dl.file_path(jid)
    if not path:
        abort(404)
    name = re.sub(r"\s*\[[A-Za-z0-9_-]{11}\]", "", path.name).strip() or path.name
    return send_file(path, as_attachment=True, download_name=name, conditional=True, max_age=0)


@app.get("/api/thumb/<vid>")
@app.get("/api/thumb/<vid>.jpg")
def api_thumb(vid):
    if vid.lower().endswith(".jpg"):
        vid = vid[:-4]
    content = dl.fetch_thumb(vid, request.args.get("q"))
    if not content:
        abort(404)
    return Response(content, mimetype="image/jpeg", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "ffmpeg": bool(dl.FFMPEG), "pages": len(pseo.PAGES)})


@app.get("/api/ping")
def api_ping():
    return jsonify({"ok": True, "ffmpeg": bool(dl.FFMPEG), "pages": len(pseo.PAGES)})


# ───────────────────────────── admin ─────────────────────────────
def admin_ok() -> bool:
    return bool(session.get("admin"))


def require_admin():
    if not admin_ok():
        return redirect(url_for("admin_login", next=request.path))
    return None


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if db.check_password(request.form.get("password", "")):
            session["admin"] = True
            session.permanent = True
            return redirect(request.args.get("next") or url_for("admin_dashboard"))
        flash("Mot de passe incorrect.", "error")
    return render_template("admin/login.html")


@app.get("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))


def admin_page_list():
    enabled = db.enabled_map()
    overrides = db.all_overrides()
    views = {r["slug"]: r["views"] for r in db.top_pages(10000)}
    rows = []
    for slug, p in sorted(pseo.PAGES.items(), key=lambda kv: (-kv[1].get("priority", 0), kv[0])):
        ov = overrides.get(slug)
        rows.append({
            "slug": slug, "kind": p["kind"], "title": (ov or {}).get("title") or p["title"],
            "enabled": enabled.get(slug, True), "views": views.get(slug, 0),
            "custom": False, "priority": p.get("priority", 0.5),
            "has_override": bool(ov),
        })
    for slug, ov in overrides.items():
        if ov.get("custom"):
            rows.append({
                "slug": slug, "kind": "custom", "title": ov.get("title") or slug,
                "enabled": bool(ov.get("enabled", 1)), "views": views.get(slug, 0),
                "custom": True, "priority": 0.5, "has_override": True,
            })
    return rows


@app.get("/admin")
def admin_dashboard():
    r = require_admin()
    if r:
        return r
    series_v = db.views_series(14)
    series_d = db.downloads_series(14)
    maxv = max([s["views"] for s in series_v] + [1])
    maxd = max([s["downloads"] for s in series_d] + [1])
    merged = []
    for a, b in zip(series_v, series_d):
        merged.append({"day": a["day"], "views": a["views"], "downloads": b["downloads"],
                       "vh": max(4, round(a["views"] / maxv * 100)),
                       "dh": max(2, round(b["downloads"] / maxd * 100))})
    pages_rows = admin_page_list()
    return render_template(
        "admin/dashboard.html",
        views_total=db.views_total(), views_today=db.views_today(),
        dl_stats=db.downloads_count(), pages_count=len(pages_rows),
        enabled_count=sum(1 for p in pages_rows if p["enabled"]),
        chart=merged, top=db.top_pages(8), jobs=db.jobs(6),
        cells=db.db_size(),
        yt_dlp_ver=getattr(getattr(dl, "yt_dlp", None), "version", None) and dl.yt_dlp.version.__version__,
        ffmpeg=bool(dl.FFMPEG),
        settings={k: db.get_setting(k) for k in ("site_name", "site_tagline", "analytics")},
        active="dashboard",
    )


@app.get("/admin/pages")
def admin_pages():
    r = require_admin()
    if r:
        return r
    rows = admin_page_list()
    q = (request.args.get("q") or "").lower()
    if q:
        rows = [p for p in rows if q in p["slug"].lower() or q in p["title"].lower()]
    return render_template("admin/pages.html", rows=rows, q=q, active="pages")


@app.route("/admin/pages/new", methods=["GET", "POST"])
def admin_page_new():
    r = require_admin()
    if r:
        return r
    if request.method == "POST":
        slug = re.sub(r"[^a-z0-9-]+", "-", (request.form.get("slug") or "").lower()).strip("-")
        if not slug:
            flash("Le slug est obligatoire.", "error")
        elif slug in pseo.PAGES or db.get_override(slug):
            flash("Ce slug existe déjà.", "error")
        else:
            db.upsert_page(
                slug, kind="custom", custom=1, enabled=1,
                title=request.form.get("title") or slug,
                description=request.form.get("description") or "",
                h1=request.form.get("h1") or "",
                intro=request.form.get("intro") or "",
                body=request.form.get("body") or "",
                faq=request.form.get("faq") or "",
            )
            flash(f"Page /{slug} créée.", "ok")
            return redirect(url_for("admin_pages"))
    return render_template("admin/page_new.html", active="pages")


@app.route("/admin/pages/<slug>/edit", methods=["GET", "POST"])
def admin_page_edit(slug):
    r = require_admin()
    if r:
        return r
    base = pseo.PAGES.get(slug)
    ov = db.get_override(slug) or {}
    if not base and not ov:
        abort(404)
    if request.method == "POST":
        action = request.form.get("action", "save")
        if action == "delete" and ov.get("custom"):
            db.delete_page(slug)
            flash("Page supprimée.", "ok")
            return redirect(url_for("admin_pages"))
        if action == "reset" and base:
            db.delete_page(slug)
            flash("Surcharges réinitialisées.", "ok")
            return redirect(url_for("admin_page_edit", slug=slug))
        db.upsert_page(
            slug,
            kind=(ov.get("kind") if ov.get("custom") else base["kind"]),
            custom=1 if ov.get("custom") else 0,
            enabled=1 if request.form.get("enabled") else 0,
            title=request.form.get("title") or "",
            description=request.form.get("description") or "",
            h1=request.form.get("h1") or "",
            intro=request.form.get("intro") or "",
            body=request.form.get("body") or (ov.get("body") or ""),
            faq=request.form.get("faq") or (ov.get("faq") or ""),
        )
        flash("Page enregistrée.", "ok")
        return redirect(url_for("admin_page_edit", slug=slug))
    from datetime import datetime
    updated = datetime.fromtimestamp(ov["updated_at"]).strftime("%d/%m/%Y %H:%M") if ov.get("updated_at") else "jamais"
    return render_template("admin/page_edit.html", slug=slug, base=base, ov=ov, updated=updated,
                           effective=effective_page(slug) or base, active="pages")


@app.post("/admin/pages/<slug>/toggle")
def admin_page_toggle(slug):
    r = require_admin()
    if r:
        return r
    ov = db.get_override(slug) or {}
    current = ov.get("enabled", 1) if ov else 1
    db.upsert_page(
        slug, enabled=0 if current else 1,
        kind=ov.get("kind") or (pseo.PAGES.get(slug) or {}).get("kind", "custom"),
        custom=1 if ov.get("custom") else 0,
        title=ov.get("title") or "", description=ov.get("description") or "",
        h1=ov.get("h1") or "", intro=ov.get("intro") or "",
        body=ov.get("body") or "", faq=ov.get("faq") or "",
    )
    flash("Statut de la page mis à jour.", "ok")
    return redirect(request.referrer or url_for("admin_pages"))


@app.get("/admin/downloads")
def admin_downloads():
    r = require_admin()
    if r:
        return r
    return render_template("admin/downloads.html", jobs=db.jobs(100),
                           stats=db.downloads_count(), active="downloads")


@app.post("/admin/downloads/<jid>/delete")
def admin_download_delete(jid):
    r = require_admin()
    if r:
        return r
    db.delete_job(jid)
    flash("Entrée supprimée.", "ok")
    return redirect(url_for("admin_downloads"))


@app.route("/admin/ai", methods=["GET", "POST"])
def admin_ai():
    r = require_admin()
    if r:
        return r
    form, result, error = {}, None, None
    if request.method == "POST":
        form = {"topic": request.form.get("topic", "").strip(),
                "keywords": request.form.get("keywords", "").strip(),
                "lang": request.form.get("lang", "fr")}
        if not form["topic"]:
            flash("Décrivez d'abord un sujet.", "error")
        else:
            try:
                gen = gemini.generate_page(form["topic"], form["keywords"], form["lang"])
                slug = gen["slug"] or "page-ia"
                base, i = slug, 2
                while slug in pseo.PAGES or db.get_override(slug):
                    slug, i = f"{base}-{i}", i + 1
                db.upsert_page(
                    slug, kind="custom", custom=1, enabled=0,
                    title=gen.get("title", "")[:180],
                    description=gen.get("description", "")[:320],
                    h1=gen.get("h1", ""), intro=gen.get("intro", ""),
                    body=gen.get("body", ""),
                    faq=gemini.faq_to_text(gen.get("faq", [])),
                )
                gen["slug"] = slug
                gen["faq_text"] = gemini.faq_to_text(gen.get("faq", []))
                result = gen
                flash("Page générée en brouillon. Relisez-la puis activez-la.", "ok")
            except Exception as e:  # noqa: BLE001
                error = str(e)
                flash(error, "error")
    return render_template("admin/ai.html", form=form, result=result, error=error,
                           ai_enabled=gemini.enabled(), model=gemini.MODEL,
                           active="ai", page_count=len(pseo.PAGES) + len(db.custom_pages()))


@app.route("/admin/settings", methods=["GET", "POST"])
def admin_settings():
    r = require_admin()
    if r:
        return r
    if request.method == "POST":
        action = request.form.get("action", "site")
        if action == "site":
            db.set_setting("site_name", request.form.get("site_name") or "ytultra")
            db.set_setting("site_tagline", request.form.get("site_tagline") or "")
            db.set_setting("default_quality", request.form.get("default_quality") or "1080")
            db.set_setting("analytics", "1" if request.form.get("analytics") else "0")
            flash("Réglages enregistrés.", "ok")
        elif action == "seo":
            db.set_setting("robots", request.form.get("robots") or "")
            flash("Fichier robots.txt mis à jour.", "ok")
        elif action == "password":
            current = request.form.get("current") or ""
            new = request.form.get("new") or ""
            if not db.check_password(current):
                flash("Mot de passe actuel incorrect.", "error")
            elif len(new) < 6:
                flash("Le nouveau mot de passe doit contenir au moins 6 caractères.", "error")
            else:
                db.set_password(new)
                flash("Mot de passe modifié.", "ok")
        return redirect(url_for("admin_settings"))
    return render_template(
        "admin/settings.html",
        settings={k: db.get_setting(k) for k in ("site_name", "site_tagline", "default_quality", "analytics", "robots")},
        sitemap_url=request.url_root.rstrip("/") + "/sitemap.xml",
        robots_url=request.url_root.rstrip("/") + "/robots.txt",
        pages_count=len(pseo.PAGES), active="settings",
    )


@app.errorhandler(404)
def not_found(_):
    if request.path.startswith("/admin"):
        return render_template("admin/404.html"), 404
    return render_template("404.html"), 404


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    print(f"▶ ytultra → http://0.0.0.0:{port}  (pSEO: {len(pseo.PAGES)} pages, ffmpeg: {dl.FFMPEG})")
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False)
